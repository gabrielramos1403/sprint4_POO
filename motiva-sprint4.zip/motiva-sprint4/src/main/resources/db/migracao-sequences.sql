-- Executado automaticamente pelo Spring Boot na inicializacao (spring.sql.init).
-- E idempotente: pode rodar em toda subida sem alterar nada que ja esteja certo.
--
-- 1. Se alguma tabela da Sprint 3 nao existir no usuario, ela e criada
--    (mesma modelagem da Sprint 3, com a PK alimentada por sequence).
-- 2. Se a tabela veio da Sprint 3 com PK "GENERATED ALWAYS AS IDENTITY",
--    o IDENTITY e removido (os dados sao mantidos).
-- 3. Cria as sequences usadas pelo @SequenceGenerator das entidades,
--    comecando no maior ID existente + 1.
-- 4. Se o banco estava vazio, cadastra a massa inicial da Sprint 3
--    (3 equipes e 5 trechos).
DECLARE
    v_qtd        NUMBER;

    FUNCTION tabela_existe(p_tabela IN VARCHAR2) RETURN BOOLEAN IS
        v_qtd_tab NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_qtd_tab FROM USER_TABLES WHERE TABLE_NAME = p_tabela;
        RETURN v_qtd_tab > 0;
    END tabela_existe;

    PROCEDURE criar_tabela(p_tabela IN VARCHAR2, p_ddl IN VARCHAR2) IS
    BEGIN
        IF NOT tabela_existe(p_tabela) THEN
            EXECUTE IMMEDIATE p_ddl;
        END IF;
    END criar_tabela;

    PROCEDURE migrar(p_tabela IN VARCHAR2, p_sequence IN VARCHAR2) IS
        v_identity NUMBER;
        v_existe   NUMBER;
        v_inicio   NUMBER;
    BEGIN
        SELECT COUNT(*) INTO v_identity
          FROM USER_TAB_IDENTITY_COLS
         WHERE TABLE_NAME = p_tabela AND COLUMN_NAME = 'ID';

        IF v_identity > 0 THEN
            EXECUTE IMMEDIATE 'ALTER TABLE ' || p_tabela || ' MODIFY ID DROP IDENTITY';
        END IF;

        SELECT COUNT(*) INTO v_existe FROM USER_SEQUENCES WHERE SEQUENCE_NAME = p_sequence;

        IF v_existe = 0 THEN
            EXECUTE IMMEDIATE 'SELECT NVL(MAX(ID), 0) + 1 FROM ' || p_tabela INTO v_inicio;
            EXECUTE IMMEDIATE 'CREATE SEQUENCE ' || p_sequence
                           || ' START WITH ' || v_inicio || ' INCREMENT BY 1 NOCACHE';
        END IF;
    END migrar;
BEGIN
    -- 1. Tabelas (somente as que nao existirem)
    criar_tabela('EQUIPE_MANUTENCAO',
        'CREATE TABLE EQUIPE_MANUTENCAO ('
        || ' ID NUMBER PRIMARY KEY,'
        || ' NOME_EQUIPE VARCHAR2(100) NOT NULL,'
        || ' ESPECIALIDADE VARCHAR2(30) NOT NULL,'
        || ' ATIVA CHAR(1) DEFAULT ''S'' NOT NULL,'
        || ' CONSTRAINT CK_EQUIPE_ESPECIALIDADE CHECK (ESPECIALIDADE IN (''MECANIZADA'', ''MANUAL'', ''PREVENTIVA'')),'
        || ' CONSTRAINT CK_EQUIPE_ATIVA CHECK (ATIVA IN (''S'', ''N'')))');

    criar_tabela('TRECHO_RODOVIA',
        'CREATE TABLE TRECHO_RODOVIA ('
        || ' ID NUMBER PRIMARY KEY,'
        || ' KM_INICIAL NUMBER(6) NOT NULL,'
        || ' KM_FINAL NUMBER(6) NOT NULL,'
        || ' DESCRICAO VARCHAR2(200),'
        || ' TIPO_AMBIENTE VARCHAR2(10) NOT NULL,'
        || ' ALTURA_VEGETACAO_CM NUMBER(6,2) NOT NULL,'
        || ' AREA_SINALIZACAO CHAR(1) DEFAULT ''N'' NOT NULL,'
        || ' ACESSO_DIFICIL CHAR(1) DEFAULT ''N'' NOT NULL,'
        || ' CODIGO_SENSOR VARCHAR2(30),'
        || ' CONSTRAINT CK_TRECHO_AMBIENTE CHECK (TIPO_AMBIENTE IN (''UMIDO'', ''SECO'')),'
        || ' CONSTRAINT CK_TRECHO_SINALIZACAO CHECK (AREA_SINALIZACAO IN (''S'', ''N'')),'
        || ' CONSTRAINT CK_TRECHO_ACESSO CHECK (ACESSO_DIFICIL IN (''S'', ''N'')),'
        || ' CONSTRAINT CK_TRECHO_KM CHECK (KM_FINAL >= KM_INICIAL))');

    criar_tabela('INTERVENCAO_OPERACIONAL',
        'CREATE TABLE INTERVENCAO_OPERACIONAL ('
        || ' ID NUMBER PRIMARY KEY,'
        || ' TRECHO_ID NUMBER NOT NULL,'
        || ' EQUIPE_ID NUMBER NOT NULL,'
        || ' TIPO_INTERVENCAO VARCHAR2(30) NOT NULL,'
        || ' DATA_EXECUCAO TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL,'
        || ' RESULTADO VARCHAR2(300),'
        || ' CONSTRAINT FK_INTERVENCAO_TRECHO FOREIGN KEY (TRECHO_ID) REFERENCES TRECHO_RODOVIA (ID),'
        || ' CONSTRAINT FK_INTERVENCAO_EQUIPE FOREIGN KEY (EQUIPE_ID) REFERENCES EQUIPE_MANUTENCAO (ID),'
        || ' CONSTRAINT CK_INTERVENCAO_TIPO CHECK (TIPO_INTERVENCAO IN (''RocadaManual'', ''RocadaMecanizada'', ''Pulverizacao'')))');

    criar_tabela('RELATORIO_PRIORIDADE',
        'CREATE TABLE RELATORIO_PRIORIDADE ('
        || ' ID NUMBER PRIMARY KEY,'
        || ' DATA_GERACAO TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL,'
        || ' QT_BAIXA NUMBER DEFAULT 0 NOT NULL,'
        || ' QT_MEDIA NUMBER DEFAULT 0 NOT NULL,'
        || ' QT_ALTA NUMBER DEFAULT 0 NOT NULL,'
        || ' QT_CRITICA NUMBER DEFAULT 0 NOT NULL,'
        || ' RESUMO VARCHAR2(500))');

    -- 2 e 3. IDENTITY -> sequences
    migrar('EQUIPE_MANUTENCAO',       'SEQ_EQUIPE_MANUTENCAO');
    migrar('TRECHO_RODOVIA',          'SEQ_TRECHO_RODOVIA');
    migrar('INTERVENCAO_OPERACIONAL', 'SEQ_INTERVENCAO_OPERACIONAL');
    migrar('RELATORIO_PRIORIDADE',    'SEQ_RELATORIO_PRIORIDADE');

    -- 4. Massa inicial da Sprint 3 (somente se nao houver nenhuma equipe nem trecho)
    EXECUTE IMMEDIATE 'SELECT (SELECT COUNT(*) FROM EQUIPE_MANUTENCAO) + (SELECT COUNT(*) FROM TRECHO_RODOVIA) FROM DUAL'
        INTO v_qtd;

    IF v_qtd = 0 THEN
        EXECUTE IMMEDIATE 'INSERT INTO EQUIPE_MANUTENCAO (ID, NOME_EQUIPE, ESPECIALIDADE, ATIVA) VALUES (SEQ_EQUIPE_MANUTENCAO.NEXTVAL, ''Equipe Mecanizada A'', ''MECANIZADA'', ''S'')';
        EXECUTE IMMEDIATE 'INSERT INTO EQUIPE_MANUTENCAO (ID, NOME_EQUIPE, ESPECIALIDADE, ATIVA) VALUES (SEQ_EQUIPE_MANUTENCAO.NEXTVAL, ''Equipe Manual B'', ''MANUAL'', ''S'')';
        EXECUTE IMMEDIATE 'INSERT INTO EQUIPE_MANUTENCAO (ID, NOME_EQUIPE, ESPECIALIDADE, ATIVA) VALUES (SEQ_EQUIPE_MANUTENCAO.NEXTVAL, ''Equipe Preventiva C'', ''PREVENTIVA'', ''S'')';

        EXECUTE IMMEDIATE 'INSERT INTO TRECHO_RODOVIA (ID, KM_INICIAL, KM_FINAL, DESCRICAO, TIPO_AMBIENTE, ALTURA_VEGETACAO_CM, AREA_SINALIZACAO, ACESSO_DIFICIL, CODIGO_SENSOR) VALUES (SEQ_TRECHO_RODOVIA.NEXTVAL, 10, 11, ''Trecho seco com boa visibilidade'', ''SECO'', 38, ''N'', ''N'', NULL)';
        EXECUTE IMMEDIATE 'INSERT INTO TRECHO_RODOVIA (ID, KM_INICIAL, KM_FINAL, DESCRICAO, TIPO_AMBIENTE, ALTURA_VEGETACAO_CM, AREA_SINALIZACAO, ACESSO_DIFICIL, CODIGO_SENSOR) VALUES (SEQ_TRECHO_RODOVIA.NEXTVAL, 12, 13, ''Trecho umido proximo a mata'', ''UMIDO'', 55, ''N'', ''N'', NULL)';
        EXECUTE IMMEDIATE 'INSERT INTO TRECHO_RODOVIA (ID, KM_INICIAL, KM_FINAL, DESCRICAO, TIPO_AMBIENTE, ALTURA_VEGETACAO_CM, AREA_SINALIZACAO, ACESSO_DIFICIL, CODIGO_SENSOR) VALUES (SEQ_TRECHO_RODOVIA.NEXTVAL, 14, 15, ''Trecho com placa de sinalizacao'', ''UMIDO'', 75, ''S'', ''N'', NULL)';
        EXECUTE IMMEDIATE 'INSERT INTO TRECHO_RODOVIA (ID, KM_INICIAL, KM_FINAL, DESCRICAO, TIPO_AMBIENTE, ALTURA_VEGETACAO_CM, AREA_SINALIZACAO, ACESSO_DIFICIL, CODIGO_SENSOR) VALUES (SEQ_TRECHO_RODOVIA.NEXTVAL, 16, 17, ''Trecho com sensor IoT instalado'', ''UMIDO'', 68, ''N'', ''N'', ''IOT-016'')';
        EXECUTE IMMEDIATE 'INSERT INTO TRECHO_RODOVIA (ID, KM_INICIAL, KM_FINAL, DESCRICAO, TIPO_AMBIENTE, ALTURA_VEGETACAO_CM, AREA_SINALIZACAO, ACESSO_DIFICIL, CODIGO_SENSOR) VALUES (SEQ_TRECHO_RODOVIA.NEXTVAL, 18, 19, ''Trecho de acostamento com acesso dificil'', ''SECO'', 92, ''N'', ''S'', NULL)';
        COMMIT;
    END IF;
END;
/
