package br.com.motiva.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("Pulverizacao")
public class Pulverizacao extends IntervencaoOperacional {

    protected Pulverizacao() {
        super();
    }

    public Pulverizacao(EquipeManutencao equipe) {
        super(equipe);
    }

    @Override
    public String executarServico(TrechoRodovia trecho) {
        trecho.setAlturaVegetacaoCm(trecho.getAlturaVegetacaoCm() - 5);
        return "Pulverizacao preventiva executada pela " + getEquipe().getNomeEquipe()
                + ". Crescimento da vegetacao controlado.";
    }

    @Override
    public Especialidade getEspecialidadeExigida() {
        return Especialidade.PREVENTIVA;
    }

    @Override
    public TipoIntervencao getTipo() {
        return TipoIntervencao.PULVERIZACAO;
    }
}
