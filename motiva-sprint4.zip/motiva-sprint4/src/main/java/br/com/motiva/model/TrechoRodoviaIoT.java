package br.com.motiva.model;

import java.util.Random;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.Transient;

/**
 * Subclasse da Sprint 2 mantida como entidade JPA. Fica na mesma tabela
 * TRECHO_RODOVIA (SINGLE_TABLE); o Hibernate instancia esta classe sempre
 * que a linha tem CODIGO_SENSOR preenchido.
 */
@Entity
@DiscriminatorValue("IOT")
public class TrechoRodoviaIoT extends TrechoRodovia implements MonitoravelViaIoT {

    @Column(name = "CODIGO_SENSOR", length = 30)
    private String codigoSensor;

    /** Nao e coluna: so simula a variacao da leitura do sensor. */
    @Transient
    private final Random random = new Random();

    /** Construtor exigido pela JPA. */
    protected TrechoRodoviaIoT() {
        super();
    }

    public TrechoRodoviaIoT(Integer kmInicial, Integer kmFinal, String descricao, TipoAmbiente tipoAmbiente,
                            Double alturaVegetacaoCm, Boolean areaSinalizacao, Boolean acessoDificil,
                            String codigoSensor) {
        super(kmInicial, kmFinal, descricao, tipoAmbiente, alturaVegetacaoCm, areaSinalizacao, acessoDificil);
        this.codigoSensor = codigoSensor;
    }

    /**
     * Mesmo comportamento da Sprint 2: o sensor le a altura atual com uma
     * variacao de 0 a 10 cm e atualiza o valor do trecho.
     */
    @Override
    public double transmitirDadosSensor() {
        double leituraSensor = getAlturaVegetacaoCm() + random.nextDouble() * 10;
        setAlturaVegetacaoCm(leituraSensor);
        return getAlturaVegetacaoCm();
    }

    @Override
    public String getCodigoSensor() {
        return codigoSensor;
    }

    public void setCodigoSensor(String codigoSensor) {
        this.codigoSensor = codigoSensor;
    }
}
