package br.com.motiva.model;

/**
 * Mesma interface da Sprint 2: qualquer trecho que tenha sensor IoT
 * sabe transmitir a leitura atual da altura da vegetacao.
 */
public interface MonitoravelViaIoT {
    double transmitirDadosSensor();
}
