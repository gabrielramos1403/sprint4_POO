package br.com.motiva.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("RocadaMecanizada")
public class RocadaMecanizada extends IntervencaoOperacional {

    protected RocadaMecanizada() {
        super();
    }

    public RocadaMecanizada(EquipeManutencao equipe) {
        super(equipe);
    }

    @Override
    public String executarServico(TrechoRodovia trecho) {
        trecho.setAlturaVegetacaoCm(8.0);
        return "Rocada mecanizada executada pela " + getEquipe().getNomeEquipe()
                + ". Vegetacao reduzida para 8 cm.";
    }

    @Override
    public Especialidade getEspecialidadeExigida() {
        return Especialidade.MECANIZADA;
    }

    @Override
    public TipoIntervencao getTipo() {
        return TipoIntervencao.ROCADA_MECANIZADA;
    }
}
