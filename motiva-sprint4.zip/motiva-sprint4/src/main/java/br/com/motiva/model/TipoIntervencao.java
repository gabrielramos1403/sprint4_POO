package br.com.motiva.model;

/**
 * Tipos de intervencao aceitos pela API. Cada constante sabe criar a
 * subclasse correspondente de IntervencaoOperacional (factory), evitando
 * if/else espalhado pelo codigo.
 */
public enum TipoIntervencao {

    ROCADA_MECANIZADA("RocadaMecanizada", Especialidade.MECANIZADA) {
        @Override
        public IntervencaoOperacional criar(EquipeManutencao equipe) {
            return new RocadaMecanizada(equipe);
        }
    },
    ROCADA_MANUAL("RocadaManual", Especialidade.MANUAL) {
        @Override
        public IntervencaoOperacional criar(EquipeManutencao equipe) {
            return new RocadaManual(equipe);
        }
    },
    PULVERIZACAO("Pulverizacao", Especialidade.PREVENTIVA) {
        @Override
        public IntervencaoOperacional criar(EquipeManutencao equipe) {
            return new Pulverizacao(equipe);
        }
    };

    /** Valor gravado na coluna TIPO_INTERVENCAO (mesmo da Sprint 3). */
    private final String valorBanco;
    private final Especialidade especialidadeExigida;

    TipoIntervencao(String valorBanco, Especialidade especialidadeExigida) {
        this.valorBanco = valorBanco;
        this.especialidadeExigida = especialidadeExigida;
    }

    public abstract IntervencaoOperacional criar(EquipeManutencao equipe);

    public String getValorBanco() {
        return valorBanco;
    }

    public Especialidade getEspecialidadeExigida() {
        return especialidadeExigida;
    }
}
