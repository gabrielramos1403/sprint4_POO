package br.com.motiva.dto;

import br.com.motiva.model.TipoAmbiente;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

/**
 * Contrato de ENTRADA da API para criar/atualizar um trecho.
 * Separar o DTO da entidade evita que o cliente controle campos internos
 * (ex.: id) e deixa a API independente do mapeamento JPA.
 */
public record TrechoRodoviaRequest(

        @NotNull(message = "kmInicial e obrigatorio")
        @PositiveOrZero(message = "kmInicial nao pode ser negativo")
        @Max(value = 999999, message = "kmInicial deve ter no maximo 6 digitos")
        Integer kmInicial,

        @NotNull(message = "kmFinal e obrigatorio")
        @PositiveOrZero(message = "kmFinal nao pode ser negativo")
        @Max(value = 999999, message = "kmFinal deve ter no maximo 6 digitos")
        Integer kmFinal,

        @Size(max = 200, message = "descricao deve ter no maximo 200 caracteres")
        String descricao,

        @NotNull(message = "tipoAmbiente e obrigatorio (UMIDO ou SECO)")
        TipoAmbiente tipoAmbiente,

        @NotNull(message = "alturaVegetacaoCm e obrigatoria")
        @PositiveOrZero(message = "alturaVegetacaoCm nao pode ser negativa")
        @DecimalMax(value = "9999.99", message = "alturaVegetacaoCm deve ser no maximo 9999.99")
        Double alturaVegetacaoCm,

        Boolean areaSinalizacao,

        Boolean acessoDificil,

        @Size(max = 30, message = "codigoSensor deve ter no maximo 30 caracteres")
        String codigoSensor
) {
}
