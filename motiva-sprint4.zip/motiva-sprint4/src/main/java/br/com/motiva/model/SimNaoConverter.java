package br.com.motiva.model;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

/**
 * As colunas booleanas da Sprint 3 foram modeladas como CHAR(1) com 'S'/'N'
 * (ATIVA, AREA_SINALIZACAO, ACESSO_DIFICIL). No JDBC puro a conversao era
 * feita na mao em cada DAO (ativa ? "S" : "N" e rs.getString(...).equals("S")).
 * Com JPA, este conversor faz isso automaticamente em todo INSERT/UPDATE/SELECT.
 */
@Converter
public class SimNaoConverter implements AttributeConverter<Boolean, String> {

    @Override
    public String convertToDatabaseColumn(Boolean valor) {
        return Boolean.TRUE.equals(valor) ? "S" : "N";
    }

    @Override
    public Boolean convertToEntityAttribute(String valor) {
        return valor != null && "S".equalsIgnoreCase(valor.trim());
    }
}
