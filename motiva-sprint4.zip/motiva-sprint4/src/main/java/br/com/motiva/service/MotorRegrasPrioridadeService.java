package br.com.motiva.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.motiva.dto.ItemRelatorioResponse;
import br.com.motiva.dto.RelatorioResponse;
import br.com.motiva.model.EquipeManutencao;
import br.com.motiva.model.IntervencaoOperacional;
import br.com.motiva.model.MonitoravelViaIoT;
import br.com.motiva.model.Prioridade;
import br.com.motiva.model.RelatorioPrioridade;
import br.com.motiva.model.TipoAmbiente;
import br.com.motiva.model.TipoIntervencao;
import br.com.motiva.model.TrechoRodovia;
import br.com.motiva.repository.EquipeManutencaoRepository;
import br.com.motiva.repository.IntervencaoOperacionalRepository;
import br.com.motiva.repository.RelatorioPrioridadeRepository;
import br.com.motiva.repository.TrechoRodoviaRepository;

/**
 * Motor de regras de prioridade (Sprint 2), agora como @Service.
 *
 * A logica de decisao (definirPrioridade / definirIntervencao) e a MESMA
 * das Sprints 2 e 3, com os mesmos limiares. O que mudou foi a forma de
 * persistir: em vez de chamar DAOs com JDBC, o motor usa os Repositories
 * do Spring Data, e tudo roda dentro de uma unica transacao (@Transactional):
 * se algo falhar no meio, nada fica gravado pela metade.
 *
 * IMPORTANTE: esta regra vive no Service e nunca no Controller.
 */
@Service
public class MotorRegrasPrioridadeService {

    // Limiares de prioridade da Sprint 2 (altura da vegetacao em cm)
    public static final double LIMIAR_CRITICA_CM = 90.0;
    public static final double LIMIAR_ALTA_CM = 70.0;
    public static final double LIMIAR_MEDIA_CM = 45.0;

    private final TrechoRodoviaRepository trechoRepository;
    private final EquipeManutencaoRepository equipeRepository;
    private final IntervencaoOperacionalRepository intervencaoRepository;
    private final RelatorioPrioridadeRepository relatorioRepository;

    public MotorRegrasPrioridadeService(TrechoRodoviaRepository trechoRepository,
                                        EquipeManutencaoRepository equipeRepository,
                                        IntervencaoOperacionalRepository intervencaoRepository,
                                        RelatorioPrioridadeRepository relatorioRepository) {
        this.trechoRepository = trechoRepository;
        this.equipeRepository = equipeRepository;
        this.intervencaoRepository = intervencaoRepository;
        this.relatorioRepository = relatorioRepository;
    }

    /**
     * Gera o relatorio a partir dos trechos atuais e persiste no historico.
     *
     * Passo a passo (mesmo fluxo do Main da Sprint 3):
     * 1. le todos os trechos do banco;
     * 2. trechos com sensor (MonitoravelViaIoT) transmitem a leitura atual;
     * 3. para cada trecho: define a prioridade e a intervencao necessaria;
     * 4. se houver intervencao, escolhe uma equipe ativa da especialidade
     *    exigida, executa o servico (a altura muda) e grava o historico;
     * 5. salva o resumo em RELATORIO_PRIORIDADE.
     */
    @Transactional
    public RelatorioResponse gerarRelatorio() {
        List<TrechoRodovia> trechos = trechoRepository.findAllByOrderByKmInicialAsc();
        RelatorioPrioridade relatorio = new RelatorioPrioridade();
        List<ItemRelatorioResponse> itens = new ArrayList<>();
        StringBuilder resumo = new StringBuilder();

        for (TrechoRodovia trecho : trechos) {
            Double leituraIoT = null;
            if (trecho instanceof MonitoravelViaIoT sensor) {
                leituraIoT = sensor.transmitirDadosSensor();
            }

            double alturaAnterior = trecho.getAlturaVegetacaoCm();
            Prioridade prioridade = definirPrioridade(trecho);
            relatorio.contabilizar(prioridade);

            Optional<TipoIntervencao> tipoNecessario = definirIntervencao(trecho);
            String acao;
            String resultado = null;
            Long intervencaoId = null;

            if (tipoNecessario.isEmpty()) {
                acao = "Monitorar. Nao precisa de intervencao imediata.";
            } else {
                TipoIntervencao tipo = tipoNecessario.get();
                Optional<EquipeManutencao> equipe = equipeRepository
                        .findFirstByEspecialidadeAndAtivaOrderByIdAsc(tipo.getEspecialidadeExigida(), Boolean.TRUE);

                if (equipe.isEmpty()) {
                    acao = tipo.getValorBanco() + " NAO executada: nenhuma equipe ativa de especialidade "
                            + tipo.getEspecialidadeExigida() + ".";
                } else {
                    IntervencaoOperacional intervencao = tipo.criar(equipe.get());
                    resultado = intervencao.executar(trecho);
                    intervencaoId = intervencaoRepository.save(intervencao).getId();
                    acao = tipo.getValorBanco();
                }
            }

            itens.add(new ItemRelatorioResponse(
                    trecho.getId(),
                    trecho.obterIdentificacao(),
                    trecho.getTipoAmbiente().name(),
                    leituraIoT,
                    alturaAnterior,
                    prioridade,
                    acao,
                    intervencaoId,
                    resultado,
                    trecho.getAlturaVegetacaoCm()));

            resumo.append("KM ").append(trecho.getKmInicial()).append('-').append(trecho.getKmFinal())
                    .append(": ").append(prioridade)
                    .append(" (").append(tipoNecessario.map(TipoIntervencao::getValorBanco).orElse("monitorar"))
                    .append("); ");
        }

        trechoRepository.saveAll(trechos);
        relatorio.setResumo(trechos.isEmpty() ? "Nenhum trecho cadastrado." : resumo.toString().trim());
        RelatorioPrioridade salvo = relatorioRepository.save(relatorio);
        return RelatorioResponse.de(salvo, itens);
    }

    /** Regra da Sprint 2: prioridade pela altura da vegetacao. */
    public Prioridade definirPrioridade(TrechoRodovia trecho) {
        double altura = trecho.getAlturaVegetacaoCm();
        if (altura >= LIMIAR_CRITICA_CM) {
            return Prioridade.CRITICA;
        }
        if (altura >= LIMIAR_ALTA_CM) {
            return Prioridade.ALTA;
        }
        if (altura >= LIMIAR_MEDIA_CM) {
            return Prioridade.MEDIA;
        }
        return Prioridade.BAIXA;
    }

    /**
     * Regra da Sprint 2: qual intervencao aplicar.
     * - >= 70 cm com acesso dificil ou area de sinalizacao -> Rocada manual (seguranca);
     * - >= 70 cm nos demais casos -> Rocada mecanizada;
     * - >= 45 cm em ambiente UMIDO -> Pulverizacao preventiva;
     * - caso contrario -> apenas monitorar.
     */
    public Optional<TipoIntervencao> definirIntervencao(TrechoRodovia trecho) {
        double altura = trecho.getAlturaVegetacaoCm();

        if (altura >= LIMIAR_ALTA_CM) {
            if (Boolean.TRUE.equals(trecho.getAcessoDificil()) || Boolean.TRUE.equals(trecho.getAreaSinalizacao())) {
                return Optional.of(TipoIntervencao.ROCADA_MANUAL);
            }
            return Optional.of(TipoIntervencao.ROCADA_MECANIZADA);
        }

        if (altura >= LIMIAR_MEDIA_CM && trecho.getTipoAmbiente() == TipoAmbiente.UMIDO) {
            return Optional.of(TipoIntervencao.PULVERIZACAO);
        }

        return Optional.empty();
    }
}
