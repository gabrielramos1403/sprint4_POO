package br.com.motiva.model;

/**
 * Niveis de prioridade de rocada definidos na Sprint 2.
 * Os limiares (90 / 70 / 45 cm) sao aplicados pelo MotorRegrasPrioridadeService,
 * e nao aqui, porque sao regra de negocio.
 */
public enum Prioridade {
    BAIXA,
    MEDIA,
    ALTA,
    CRITICA
}
