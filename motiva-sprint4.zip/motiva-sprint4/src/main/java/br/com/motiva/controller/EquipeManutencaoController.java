package br.com.motiva.controller;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.motiva.dto.EquipeManutencaoRequest;
import br.com.motiva.dto.EquipeManutencaoResponse;
import br.com.motiva.model.Especialidade;
import br.com.motiva.service.EquipeManutencaoService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/equipes")
public class EquipeManutencaoController {

    private final EquipeManutencaoService service;

    public EquipeManutencaoController(EquipeManutencaoService service) {
        this.service = service;
    }

    /** GET /api/equipes[?especialidade=MANUAL][?nome=preventiva] -> 200 */
    @GetMapping
    public ResponseEntity<List<EquipeManutencaoResponse>> listar(
            @RequestParam(name = "especialidade", required = false) Especialidade especialidade,
            @RequestParam(name = "nome", required = false) String nome) {
        return ResponseEntity.ok(service.listar(especialidade, nome));
    }

    /** GET /api/equipes/{id} -> 200 ou 404 */
    @GetMapping("/{id}")
    public ResponseEntity<EquipeManutencaoResponse> buscarPorId(@PathVariable("id") Long id) {
        return ResponseEntity.ok(service.buscarPorId(id));
    }

    /** POST /api/equipes -> 201 (ou 400) */
    @PostMapping
    public ResponseEntity<EquipeManutencaoResponse> criar(@Valid @RequestBody EquipeManutencaoRequest dados) {
        EquipeManutencaoResponse criada = service.criar(dados);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(criada.id()).toUri();
        return ResponseEntity.created(location).body(criada);
    }

    /** PUT /api/equipes/{id} -> 200, 400 ou 404 */
    @PutMapping("/{id}")
    public ResponseEntity<EquipeManutencaoResponse> atualizar(@PathVariable("id") Long id,
                                                              @Valid @RequestBody EquipeManutencaoRequest dados) {
        return ResponseEntity.ok(service.atualizar(id, dados));
    }

    /** DELETE /api/equipes/{id} -> 204, 404 ou 409 (se tiver historico) */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> remover(@PathVariable("id") Long id) {
        service.remover(id);
        return ResponseEntity.noContent().build();
    }
}
