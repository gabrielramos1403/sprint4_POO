package br.com.motiva;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Ponto de entrada da API MOTIVA.
 *
 * Na Sprint 3 o Main.main() abria a conexao (ConexaoBD), chamava os DAOs na
 * mao e imprimia tudo com System.out.println. Agora o Spring Boot sobe o
 * Tomcat embutido, cria o pool de conexoes a partir do application.properties
 * e injeta Repository -> Service -> Controller. A "interface" do sistema
 * passa a ser HTTP + JSON.
 */
@SpringBootApplication
public class MotivaApplication {

    public static void main(String[] args) {
        SpringApplication.run(MotivaApplication.class, args);
    }
}
