package br.com.motiva.dto;

import br.com.motiva.model.TipoAmbiente;
import br.com.motiva.model.TrechoRodovia;

/**
 * Contrato de SAIDA da API para um trecho.
 * "possuiSensorIoT" mostra o polimorfismo: true quando o Hibernate
 * instanciou um TrechoRodoviaIoT.
 */
public record TrechoRodoviaResponse(
        Long id,
        Integer kmInicial,
        Integer kmFinal,
        String identificacao,
        String descricao,
        TipoAmbiente tipoAmbiente,
        Double alturaVegetacaoCm,
        Boolean areaSinalizacao,
        Boolean acessoDificil,
        boolean possuiSensorIoT,
        String codigoSensor
) {

    public static TrechoRodoviaResponse de(TrechoRodovia trecho) {
        return new TrechoRodoviaResponse(
                trecho.getId(),
                trecho.getKmInicial(),
                trecho.getKmFinal(),
                trecho.obterIdentificacao(),
                trecho.getDescricao(),
                trecho.getTipoAmbiente(),
                trecho.getAlturaVegetacaoCm(),
                trecho.getAreaSinalizacao(),
                trecho.getAcessoDificil(),
                trecho.possuiSensorIoT(),
                trecho.getCodigoSensor());
    }
}
