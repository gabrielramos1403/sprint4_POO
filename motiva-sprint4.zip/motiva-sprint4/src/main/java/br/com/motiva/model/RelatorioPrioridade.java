package br.com.motiva.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

/**
 * Entidade JPA mapeada para RELATORIO_PRIORIDADE: o resumo de cada execucao
 * do motor de prioridade (historico).
 */
@Entity
@Table(name = "RELATORIO_PRIORIDADE")
public class RelatorioPrioridade {

    /** Tamanho da coluna RESUMO (VARCHAR2(500)). */
    public static final int TAMANHO_MAXIMO_RESUMO = 500;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqRelatorioPrioridade")
    @SequenceGenerator(name = "seqRelatorioPrioridade", sequenceName = "SEQ_RELATORIO_PRIORIDADE",
            allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "DATA_GERACAO", nullable = false)
    private LocalDateTime dataGeracao;

    @Column(name = "QT_BAIXA", nullable = false)
    private Integer qtBaixa = 0;

    @Column(name = "QT_MEDIA", nullable = false)
    private Integer qtMedia = 0;

    @Column(name = "QT_ALTA", nullable = false)
    private Integer qtAlta = 0;

    @Column(name = "QT_CRITICA", nullable = false)
    private Integer qtCritica = 0;

    @Column(name = "RESUMO", length = TAMANHO_MAXIMO_RESUMO)
    private String resumo;

    public RelatorioPrioridade() {
    }

    /** Soma 1 no contador da prioridade informada. */
    public void contabilizar(Prioridade prioridade) {
        switch (prioridade) {
            case BAIXA -> qtBaixa++;
            case MEDIA -> qtMedia++;
            case ALTA -> qtAlta++;
            case CRITICA -> qtCritica++;
        }
    }

    public int getTotalTrechos() {
        return qtBaixa + qtMedia + qtAlta + qtCritica;
    }

    @PrePersist
    void antesDeInserir() {
        if (dataGeracao == null) {
            dataGeracao = LocalDateTime.now();
        }
    }

    public Long getId() {
        return id;
    }

    public LocalDateTime getDataGeracao() {
        return dataGeracao;
    }

    public void setDataGeracao(LocalDateTime dataGeracao) {
        this.dataGeracao = dataGeracao;
    }

    public Integer getQtBaixa() {
        return qtBaixa;
    }

    public Integer getQtMedia() {
        return qtMedia;
    }

    public Integer getQtAlta() {
        return qtAlta;
    }

    public Integer getQtCritica() {
        return qtCritica;
    }

    public String getResumo() {
        return resumo;
    }

    /** Garante que o texto cabe na coluna VARCHAR2(500). */
    public void setResumo(String resumo) {
        if (resumo != null && resumo.length() > TAMANHO_MAXIMO_RESUMO) {
            this.resumo = resumo.substring(0, TAMANHO_MAXIMO_RESUMO - 3) + "...";
        } else {
            this.resumo = resumo;
        }
    }
}
