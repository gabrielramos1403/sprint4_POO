package br.com.motiva.model;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import org.hibernate.annotations.DiscriminatorFormula;

/**
 * Entidade JPA mapeada para a tabela TRECHO_RODOVIA da Sprint 3.
 *
 * Heranca: na Sprint 3, TrechoRodovia e TrechoRodoviaIoT ja dividiam a MESMA
 * tabela, e era o metodo TrechoRodoviaDAO.paraObjetoDominio() que olhava a
 * coluna CODIGO_SENSOR para decidir qual classe instanciar. Agora quem faz
 * isso e o Hibernate: usamos InheritanceType.SINGLE_TABLE com uma
 * "discriminator formula" calculada a partir de CODIGO_SENSOR, entao
 * nenhuma coluna nova precisou ser criada no banco.
 */
@Entity
@Table(name = "TRECHO_RODOVIA")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorFormula("CASE WHEN CODIGO_SENSOR IS NULL THEN 'PADRAO' ELSE 'IOT' END")
@DiscriminatorValue("PADRAO")
public class TrechoRodovia {

    /** Limite da coluna ALTURA_VEGETACAO_CM NUMBER(6,2). */
    public static final double ALTURA_MAXIMA_CM = 9999.99;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqTrechoRodovia")
    @SequenceGenerator(name = "seqTrechoRodovia", sequenceName = "SEQ_TRECHO_RODOVIA", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "KM_INICIAL", nullable = false)
    private Integer kmInicial;

    @Column(name = "KM_FINAL", nullable = false)
    private Integer kmFinal;

    @Column(name = "DESCRICAO", length = 200)
    private String descricao;

    @Enumerated(EnumType.STRING)
    @Column(name = "TIPO_AMBIENTE", nullable = false, length = 10)
    private TipoAmbiente tipoAmbiente;

    @Column(name = "ALTURA_VEGETACAO_CM", nullable = false)
    private Double alturaVegetacaoCm;

    @Convert(converter = SimNaoConverter.class)
    @Column(name = "AREA_SINALIZACAO", nullable = false, length = 1)
    private Boolean areaSinalizacao = Boolean.FALSE;

    @Convert(converter = SimNaoConverter.class)
    @Column(name = "ACESSO_DIFICIL", nullable = false, length = 1)
    private Boolean acessoDificil = Boolean.FALSE;

    /** Construtor exigido pela JPA. */
    protected TrechoRodovia() {
    }

    public TrechoRodovia(Integer kmInicial, Integer kmFinal, String descricao, TipoAmbiente tipoAmbiente,
                         Double alturaVegetacaoCm, Boolean areaSinalizacao, Boolean acessoDificil) {
        this.kmInicial = kmInicial;
        this.kmFinal = kmFinal;
        this.tipoAmbiente = tipoAmbiente;
        setDescricao(descricao);
        setAlturaVegetacaoCm(alturaVegetacaoCm);
        setAreaSinalizacao(areaSinalizacao);
        setAcessoDificil(acessoDificil);
    }

    /** Mesmo comportamento da Sprint 1: a vegetacao cresce conforme o tipo de ambiente. */
    public void simularCrescimento(int dias) {
        if (dias <= 0) {
            throw new IllegalArgumentException("A quantidade de dias deve ser maior que zero.");
        }
        setAlturaVegetacaoCm(alturaVegetacaoCm + tipoAmbiente.getCrescimentoCmPorDia() * dias);
    }

    public String obterIdentificacao() {
        return "KM " + kmInicial + " ao KM " + kmFinal + " - " + descricao;
    }

    /** Polimorfismo: um trecho comum nao possui sensor. TrechoRodoviaIoT sobrescreve. */
    public String getCodigoSensor() {
        return null;
    }

    public boolean possuiSensorIoT() {
        return this instanceof MonitoravelViaIoT;
    }

    public Long getId() {
        return id;
    }

    public Integer getKmInicial() {
        return kmInicial;
    }

    public void setKmInicial(Integer kmInicial) {
        this.kmInicial = kmInicial;
    }

    public Integer getKmFinal() {
        return kmFinal;
    }

    public void setKmFinal(Integer kmFinal) {
        this.kmFinal = kmFinal;
    }

    public String getDescricao() {
        return descricao;
    }

    /** Regra da Sprint 1: descricao vazia vira um texto padrao. */
    public void setDescricao(String descricao) {
        if (descricao != null && !descricao.trim().isEmpty()) {
            this.descricao = descricao.trim();
        } else {
            this.descricao = "Trecho sem descricao";
        }
    }

    public TipoAmbiente getTipoAmbiente() {
        return tipoAmbiente;
    }

    public void setTipoAmbiente(TipoAmbiente tipoAmbiente) {
        this.tipoAmbiente = tipoAmbiente;
    }

    public Double getAlturaVegetacaoCm() {
        return alturaVegetacaoCm;
    }

    /**
     * Protecao da Sprint 1: a altura nunca fica negativa em memoria
     * (ex.: Pulverizacao reduz 5 cm de um trecho com 3 cm -> fica 0).
     * A validacao de ENTRADA (rejeitar altura negativa vinda da API) e
     * feita no Service, que devolve 400 ao cliente.
     */
    public void setAlturaVegetacaoCm(Double alturaVegetacaoCm) {
        if (alturaVegetacaoCm == null || alturaVegetacaoCm < 0) {
            this.alturaVegetacaoCm = 0.0;
        } else {
            // NUMBER(6,2): 2 casas decimais e no maximo 9999.99
            double arredondada = Math.round(alturaVegetacaoCm * 100.0) / 100.0;
            this.alturaVegetacaoCm = Math.min(arredondada, ALTURA_MAXIMA_CM);
        }
    }

    public Boolean getAreaSinalizacao() {
        return areaSinalizacao;
    }

    public void setAreaSinalizacao(Boolean areaSinalizacao) {
        this.areaSinalizacao = Boolean.TRUE.equals(areaSinalizacao);
    }

    public Boolean getAcessoDificil() {
        return acessoDificil;
    }

    public void setAcessoDificil(Boolean acessoDificil) {
        this.acessoDificil = Boolean.TRUE.equals(acessoDificil);
    }

    @Override
    public String toString() {
        return getClass().getSimpleName() + "{id=" + id + ", kmInicial=" + kmInicial + ", kmFinal=" + kmFinal
                + ", alturaVegetacaoCm=" + alturaVegetacaoCm + "}";
    }
}
