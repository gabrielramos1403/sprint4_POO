package br.com.motiva.dto;

import br.com.motiva.model.TipoIntervencao;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

/**
 * Contrato de ENTRADA para registrar (executar) uma intervencao.
 * Ao criar, o servico polimorfico e executado sobre o trecho
 * (a altura da vegetacao muda) e o resultado vai para o historico.
 */
public record IntervencaoRequest(

        @NotNull(message = "tipo e obrigatorio (ROCADA_MECANIZADA, ROCADA_MANUAL ou PULVERIZACAO)")
        TipoIntervencao tipo,

        @NotNull(message = "trechoId e obrigatorio")
        @Positive(message = "trechoId deve ser positivo")
        Long trechoId,

        @NotNull(message = "equipeId e obrigatorio")
        @Positive(message = "equipeId deve ser positivo")
        Long equipeId
) {
}
