package br.com.motiva.service;

import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.motiva.dto.EquipeManutencaoRequest;
import br.com.motiva.dto.EquipeManutencaoResponse;
import br.com.motiva.exception.ConflitoException;
import br.com.motiva.exception.RecursoNaoEncontradoException;
import br.com.motiva.exception.RegraNegocioException;
import br.com.motiva.model.EquipeManutencao;
import br.com.motiva.model.Especialidade;
import br.com.motiva.repository.EquipeManutencaoRepository;
import br.com.motiva.repository.IntervencaoOperacionalRepository;

@Service
public class EquipeManutencaoService {

    private final EquipeManutencaoRepository equipeRepository;
    private final IntervencaoOperacionalRepository intervencaoRepository;

    public EquipeManutencaoService(EquipeManutencaoRepository equipeRepository,
                                   IntervencaoOperacionalRepository intervencaoRepository) {
        this.equipeRepository = equipeRepository;
        this.intervencaoRepository = intervencaoRepository;
    }

    @Transactional(readOnly = true)
    public List<EquipeManutencaoResponse> listar(Especialidade especialidade, String nome) {
        List<EquipeManutencao> equipes;
        if (especialidade != null) {
            equipes = equipeRepository.findByEspecialidadeOrderByIdAsc(especialidade);
        } else if (nome != null && !nome.isBlank()) {
            equipes = equipeRepository.findByNomeEquipeContainingIgnoreCaseOrderByIdAsc(nome.trim());
        } else {
            equipes = equipeRepository.findAll(Sort.by("id"));
        }
        return equipes.stream().map(EquipeManutencaoResponse::de).toList();
    }

    @Transactional(readOnly = true)
    public EquipeManutencaoResponse buscarPorId(Long id) {
        return EquipeManutencaoResponse.de(buscarEntidade(id));
    }

    @Transactional
    public EquipeManutencaoResponse criar(EquipeManutencaoRequest dados) {
        validarRegras(dados);
        EquipeManutencao equipe = new EquipeManutencao(dados.nomeEquipe().trim(), dados.especialidade(),
                dados.ativa());
        return EquipeManutencaoResponse.de(equipeRepository.save(equipe));
    }

    @Transactional
    public EquipeManutencaoResponse atualizar(Long id, EquipeManutencaoRequest dados) {
        EquipeManutencao equipe = buscarEntidade(id);
        validarRegras(dados);
        equipe.setNomeEquipe(dados.nomeEquipe().trim());
        equipe.setEspecialidade(dados.especialidade());
        if (dados.ativa() != null) {
            equipe.setAtiva(dados.ativa());
        }
        return EquipeManutencaoResponse.de(equipeRepository.save(equipe));
    }

    @Transactional
    public void remover(Long id) {
        EquipeManutencao equipe = buscarEntidade(id);
        if (intervencaoRepository.existsByEquipeId(id)) {
            throw new ConflitoException("A equipe " + id + " possui intervencoes no historico e nao pode ser "
                    + "removida (FK_INTERVENCAO_EQUIPE). Inative-a com PUT e \"ativa\": false.");
        }
        equipeRepository.delete(equipe);
    }

    @Transactional(readOnly = true)
    public EquipeManutencao buscarEntidade(Long id) {
        return equipeRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Equipe", id));
    }

    /** Regra da Sprint 1: toda equipe precisa de nome e especialidade validos. */
    private void validarRegras(EquipeManutencaoRequest dados) {
        if (dados.nomeEquipe() == null || dados.nomeEquipe().isBlank()) {
            throw new RegraNegocioException("O nome da equipe e obrigatorio.");
        }
        if (dados.especialidade() == null) {
            throw new RegraNegocioException("Especialidade invalida. Use MECANIZADA, MANUAL ou PREVENTIVA.");
        }
    }
}
