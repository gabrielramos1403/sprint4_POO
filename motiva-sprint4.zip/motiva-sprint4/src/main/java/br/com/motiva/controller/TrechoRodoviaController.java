package br.com.motiva.controller;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.motiva.dto.TrechoRodoviaRequest;
import br.com.motiva.dto.TrechoRodoviaResponse;
import br.com.motiva.model.TipoAmbiente;
import br.com.motiva.service.TrechoRodoviaService;
import jakarta.validation.Valid;

/**
 * Endpoints REST de trechos de rodovia.
 * Sem regra de negocio aqui: o controller so traduz HTTP <-> Service.
 */
@RestController
@RequestMapping("/api/trechos")
public class TrechoRodoviaController {

    private final TrechoRodoviaService service;

    public TrechoRodoviaController(TrechoRodoviaService service) {
        this.service = service;
    }

    /** GET /api/trechos[?tipoAmbiente=UMIDO][&alturaMinima=50] -> 200 */
    @GetMapping
    public ResponseEntity<List<TrechoRodoviaResponse>> listar(
            @RequestParam(name = "tipoAmbiente", required = false) TipoAmbiente tipoAmbiente,
            @RequestParam(name = "alturaMinima", required = false) Double alturaMinima) {
        return ResponseEntity.ok(service.listar(tipoAmbiente, alturaMinima));
    }

    /** GET /api/trechos/{id} -> 200 ou 404 */
    @GetMapping("/{id}")
    public ResponseEntity<TrechoRodoviaResponse> buscarPorId(@PathVariable("id") Long id) {
        return ResponseEntity.ok(service.buscarPorId(id));
    }

    /** POST /api/trechos -> 201 + header Location + corpo criado (ou 400) */
    @PostMapping
    public ResponseEntity<TrechoRodoviaResponse> criar(@Valid @RequestBody TrechoRodoviaRequest dados) {
        TrechoRodoviaResponse criado = service.criar(dados);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(criado.id()).toUri();
        return ResponseEntity.created(location).body(criado);
    }

    /** PUT /api/trechos/{id} -> 200, 400 ou 404 */
    @PutMapping("/{id}")
    public ResponseEntity<TrechoRodoviaResponse> atualizar(@PathVariable("id") Long id,
                                                           @Valid @RequestBody TrechoRodoviaRequest dados) {
        return ResponseEntity.ok(service.atualizar(id, dados));
    }

    /** DELETE /api/trechos/{id} -> 204, 404 ou 409 (se tiver historico) */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> remover(@PathVariable("id") Long id) {
        service.remover(id);
        return ResponseEntity.noContent().build();
    }

    /** POST /api/trechos/simulacao-crescimento?dias=7 -> 200 (regra da Sprint 1) */
    @PostMapping("/simulacao-crescimento")
    public ResponseEntity<List<TrechoRodoviaResponse>> simularCrescimento(
            @RequestParam(name = "dias", defaultValue = "7") int dias) {
        return ResponseEntity.ok(service.simularCrescimento(dias));
    }
}
