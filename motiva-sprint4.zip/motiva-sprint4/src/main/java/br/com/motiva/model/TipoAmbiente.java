package br.com.motiva.model;

/**
 * Tipos de ambiente aceitos pela CHECK constraint CK_TRECHO_AMBIENTE.
 * O ambiente define a velocidade de crescimento da vegetacao (Sprint 1).
 */
public enum TipoAmbiente {

    UMIDO(1.8),
    SECO(0.8);

    private final double crescimentoCmPorDia;

    TipoAmbiente(double crescimentoCmPorDia) {
        this.crescimentoCmPorDia = crescimentoCmPorDia;
    }

    public double getCrescimentoCmPorDia() {
        return crescimentoCmPorDia;
    }
}
