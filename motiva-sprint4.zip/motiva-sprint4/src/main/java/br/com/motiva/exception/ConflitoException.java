package br.com.motiva.exception;

/**
 * Lancada quando a operacao conflita com o estado atual dos dados
 * (ex.: apagar um trecho que ja possui intervencoes no historico). Vira HTTP 409.
 */
public class ConflitoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ConflitoException(String mensagem) {
        super(mensagem);
    }
}
