package br.com.motiva.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.motiva.dto.IntervencaoRequest;
import br.com.motiva.dto.IntervencaoResponse;
import br.com.motiva.dto.IntervencaoUpdateRequest;
import br.com.motiva.exception.RecursoNaoEncontradoException;
import br.com.motiva.exception.RegraNegocioException;
import br.com.motiva.model.EquipeManutencao;
import br.com.motiva.model.Especialidade;
import br.com.motiva.model.IntervencaoOperacional;
import br.com.motiva.model.TrechoRodovia;
import br.com.motiva.repository.EquipeManutencaoRepository;
import br.com.motiva.repository.IntervencaoOperacionalRepository;
import br.com.motiva.repository.TrechoRodoviaRepository;

/**
 * Regras de negocio das intervencoes operacionais (historico de servicos).
 */
@Service
public class IntervencaoOperacionalService {

    private final IntervencaoOperacionalRepository intervencaoRepository;
    private final TrechoRodoviaRepository trechoRepository;
    private final EquipeManutencaoRepository equipeRepository;

    public IntervencaoOperacionalService(IntervencaoOperacionalRepository intervencaoRepository,
                                         TrechoRodoviaRepository trechoRepository,
                                         EquipeManutencaoRepository equipeRepository) {
        this.intervencaoRepository = intervencaoRepository;
        this.trechoRepository = trechoRepository;
        this.equipeRepository = equipeRepository;
    }

    @Transactional(readOnly = true)
    public List<IntervencaoResponse> listar(Long trechoId, Long equipeId) {
        List<IntervencaoOperacional> intervencoes;
        if (trechoId != null) {
            intervencoes = intervencaoRepository.findByTrechoIdOrderByDataExecucaoDesc(trechoId);
        } else if (equipeId != null) {
            intervencoes = intervencaoRepository.findByEquipeIdOrderByDataExecucaoDesc(equipeId);
        } else {
            intervencoes = intervencaoRepository.findAllByOrderByDataExecucaoDesc();
        }
        return intervencoes.stream().map(IntervencaoResponse::de).toList();
    }

    @Transactional(readOnly = true)
    public IntervencaoResponse buscarPorId(Long id) {
        return IntervencaoResponse.de(buscarEntidade(id));
    }

    /**
     * Registra uma intervencao: cria a subclasse certa (polimorfismo),
     * valida a equipe, EXECUTA o servico sobre o trecho (a altura muda)
     * e grava o historico. Tudo na mesma transacao.
     */
    @Transactional
    public IntervencaoResponse registrar(IntervencaoRequest dados) {
        TrechoRodovia trecho = trechoRepository.findById(dados.trechoId())
                .orElseThrow(() -> new RegraNegocioException(
                        "trechoId " + dados.trechoId() + " nao corresponde a nenhum trecho cadastrado."));
        EquipeManutencao equipe = buscarEquipeValida(dados.equipeId(), dados.tipo().getEspecialidadeExigida());

        IntervencaoOperacional intervencao = dados.tipo().criar(equipe);
        intervencao.executar(trecho);

        trechoRepository.save(trecho);
        return IntervencaoResponse.de(intervencaoRepository.save(intervencao));
    }

    @Transactional
    public IntervencaoResponse atualizar(Long id, IntervencaoUpdateRequest dados) {
        IntervencaoOperacional intervencao = buscarEntidade(id);
        EquipeManutencao equipe = buscarEquipeValida(dados.equipeId(), intervencao.getEspecialidadeExigida());

        intervencao.setEquipe(equipe);
        if (dados.resultado() != null && !dados.resultado().isBlank()) {
            intervencao.setResultado(dados.resultado().trim());
        }
        return IntervencaoResponse.de(intervencaoRepository.save(intervencao));
    }

    @Transactional
    public void remover(Long id) {
        intervencaoRepository.delete(buscarEntidade(id));
    }

    private IntervencaoOperacional buscarEntidade(Long id) {
        return intervencaoRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Intervencao", id));
    }

    /**
     * Regra de negocio: a equipe precisa existir, estar ativa e ter a
     * especialidade exigida pelo tipo de intervencao
     * (RocadaMecanizada -> MECANIZADA, RocadaManual -> MANUAL, Pulverizacao -> PREVENTIVA).
     */
    private EquipeManutencao buscarEquipeValida(Long equipeId, Especialidade especialidadeExigida) {
        EquipeManutencao equipe = equipeRepository.findById(equipeId)
                .orElseThrow(() -> new RegraNegocioException(
                        "equipeId " + equipeId + " nao corresponde a nenhuma equipe cadastrada."));

        if (!Boolean.TRUE.equals(equipe.getAtiva())) {
            throw new RegraNegocioException("A equipe " + equipe.getNomeEquipe() + " esta inativa.");
        }
        if (!equipe.podeExecutar(especialidadeExigida)) {
            throw new RegraNegocioException("A equipe " + equipe.getNomeEquipe() + " e da especialidade "
                    + equipe.getEspecialidade() + ", mas esta intervencao exige uma equipe "
                    + especialidadeExigida + ".");
        }
        return equipe;
    }
}
