package br.com.motiva.dto;

import java.time.LocalDateTime;

import br.com.motiva.model.IntervencaoOperacional;
import br.com.motiva.model.TipoIntervencao;

public record IntervencaoResponse(
        Long id,
        TipoIntervencao tipo,
        String classe,
        Long trechoId,
        String trecho,
        Double alturaAtualTrechoCm,
        Long equipeId,
        String equipe,
        LocalDateTime dataExecucao,
        String resultado
) {

    public static IntervencaoResponse de(IntervencaoOperacional intervencao) {
        return new IntervencaoResponse(
                intervencao.getId(),
                intervencao.getTipo(),
                intervencao.getTipo().getValorBanco(),
                intervencao.getTrecho().getId(),
                intervencao.getTrecho().obterIdentificacao(),
                intervencao.getTrecho().getAlturaVegetacaoCm(),
                intervencao.getEquipe().getId(),
                intervencao.getEquipe().getNomeEquipe(),
                intervencao.getDataExecucao(),
                intervencao.getResultado());
    }
}
