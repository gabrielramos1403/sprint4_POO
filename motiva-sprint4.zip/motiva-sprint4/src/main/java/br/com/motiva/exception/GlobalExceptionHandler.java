package br.com.motiva.exception;

import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.ErrorResponse;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import br.com.motiva.dto.ErroResponse;
import br.com.motiva.dto.ErroResponse.CampoInvalido;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Tratamento global de erros (@ControllerAdvice).
 * Os controllers ficam limpos: eles nao tem try/catch. Qualquer excecao
 * lancada pelos services e convertida aqui no codigo HTTP correto e em um
 * JSON de erro padronizado.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger LOG = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /** 404 - recurso nao existe. */
    @ExceptionHandler(RecursoNaoEncontradoException.class)
    public ResponseEntity<ErroResponse> tratarNaoEncontrado(RecursoNaoEncontradoException ex,
                                                            HttpServletRequest request) {
        return montar(HttpStatus.NOT_FOUND, ex.getMessage(), request, List.of());
    }

    /** 400 - regra de negocio violada (validacoes do Service). */
    @ExceptionHandler(RegraNegocioException.class)
    public ResponseEntity<ErroResponse> tratarRegraNegocio(RegraNegocioException ex, HttpServletRequest request) {
        return montar(HttpStatus.BAD_REQUEST, ex.getMessage(), request, List.of());
    }

    /** 400 - Bean Validation (@Valid) reprovou o corpo da requisicao. */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErroResponse> tratarValidacao(MethodArgumentNotValidException ex,
                                                        HttpServletRequest request) {
        List<CampoInvalido> campos = ex.getBindingResult().getFieldErrors().stream()
                .map(erro -> new CampoInvalido(erro.getField(), erro.getDefaultMessage()))
                .toList();
        return montar(HttpStatus.BAD_REQUEST, "Dados de entrada invalidos.", request, campos);
    }

    /** 400 - JSON mal formado ou valor de enum invalido (ex.: tipoAmbiente = "MOLHADO"). */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErroResponse> tratarJsonInvalido(HttpMessageNotReadableException ex,
                                                           HttpServletRequest request) {
        return montar(HttpStatus.BAD_REQUEST,
                "Corpo da requisicao invalido: verifique o formato do JSON e os valores permitidos.",
                request, List.of());
    }

    /** 400 - parametro de URL com tipo errado (ex.: /api/trechos/abc ou data invalida). */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErroResponse> tratarTipoParametro(MethodArgumentTypeMismatchException ex,
                                                            HttpServletRequest request) {
        return montar(HttpStatus.BAD_REQUEST,
                "Valor invalido para o parametro '" + ex.getName() + "': " + ex.getValue(),
                request, List.of());
    }

    /** 400 - parametro obrigatorio ausente (ex.: /api/relatorios/periodo sem "fim"). */
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<ErroResponse> tratarParametroAusente(MissingServletRequestParameterException ex,
                                                               HttpServletRequest request) {
        return montar(HttpStatus.BAD_REQUEST,
                "Parametro obrigatorio ausente: " + ex.getParameterName(), request, List.of());
    }

    /** 409 - conflito de regra (ex.: apagar trecho com historico). */
    @ExceptionHandler(ConflitoException.class)
    public ResponseEntity<ErroResponse> tratarConflito(ConflitoException ex, HttpServletRequest request) {
        return montar(HttpStatus.CONFLICT, ex.getMessage(), request, List.of());
    }

    /** 409 - o banco recusou por integridade (FK/CHECK) - ultima linha de defesa. */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ErroResponse> tratarIntegridade(DataIntegrityViolationException ex,
                                                          HttpServletRequest request) {
        LOG.warn("Violacao de integridade no banco: {}", ex.getMostSpecificCause().getMessage());
        return montar(HttpStatus.CONFLICT,
                "A operacao viola uma restricao de integridade do banco de dados.", request, List.of());
    }

    /** 404 - rota inexistente. */
    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<ErroResponse> tratarRotaInexistente(NoResourceFoundException ex,
                                                              HttpServletRequest request) {
        return montar(HttpStatus.NOT_FOUND, "Rota nao encontrada.", request, List.of());
    }

    /** 405 - metodo HTTP nao suportado na rota. */
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ErroResponse> tratarMetodoNaoSuportado(HttpRequestMethodNotSupportedException ex,
                                                                 HttpServletRequest request) {
        return montar(HttpStatus.METHOD_NOT_ALLOWED,
                "Metodo " + ex.getMethod() + " nao suportado nesta rota.", request, List.of());
    }

    /**
     * Demais erros. Excecoes do proprio Spring MVC que ja carregam um status
     * HTTP (ex.: 415 Content-Type nao suportado) mantem esse status; qualquer
     * outro erro inesperado vira 500, sem expor stack trace ao cliente.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErroResponse> tratarErroInesperado(Exception ex, HttpServletRequest request) {
        if (ex instanceof ErrorResponse erroSpring) {
            HttpStatus status = HttpStatus.resolve(erroSpring.getStatusCode().value());
            if (status != null && status.is4xxClientError()) {
                return montar(status, ex.getMessage(), request, List.of());
            }
        }
        LOG.error("Erro inesperado em {} {}", request.getMethod(), request.getRequestURI(), ex);
        return montar(HttpStatus.INTERNAL_SERVER_ERROR, "Erro interno inesperado.", request, List.of());
    }

    private ResponseEntity<ErroResponse> montar(HttpStatus status, String mensagem, HttpServletRequest request,
                                                List<CampoInvalido> campos) {
        ErroResponse corpo = new ErroResponse(
                LocalDateTime.now(),
                status.value(),
                status.getReasonPhrase(),
                mensagem,
                request.getRequestURI(),
                campos);
        return ResponseEntity.status(status).body(corpo);
    }
}
