package br.com.motiva.controller;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.motiva.dto.IntervencaoRequest;
import br.com.motiva.dto.IntervencaoResponse;
import br.com.motiva.dto.IntervencaoUpdateRequest;
import br.com.motiva.service.IntervencaoOperacionalService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/intervencoes")
public class IntervencaoOperacionalController {

    private final IntervencaoOperacionalService service;

    public IntervencaoOperacionalController(IntervencaoOperacionalService service) {
        this.service = service;
    }

    /** GET /api/intervencoes[?trechoId=1][?equipeId=2] -> 200 */
    @GetMapping
    public ResponseEntity<List<IntervencaoResponse>> listar(
            @RequestParam(name = "trechoId", required = false) Long trechoId,
            @RequestParam(name = "equipeId", required = false) Long equipeId) {
        return ResponseEntity.ok(service.listar(trechoId, equipeId));
    }

    /** GET /api/intervencoes/{id} -> 200 ou 404 */
    @GetMapping("/{id}")
    public ResponseEntity<IntervencaoResponse> buscarPorId(@PathVariable("id") Long id) {
        return ResponseEntity.ok(service.buscarPorId(id));
    }

    /** POST /api/intervencoes -> 201 (executa o servico no trecho e grava o historico) ou 400 */
    @PostMapping
    public ResponseEntity<IntervencaoResponse> registrar(@Valid @RequestBody IntervencaoRequest dados) {
        IntervencaoResponse criada = service.registrar(dados);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(criada.id()).toUri();
        return ResponseEntity.created(location).body(criada);
    }

    /** PUT /api/intervencoes/{id} -> 200, 400 ou 404 */
    @PutMapping("/{id}")
    public ResponseEntity<IntervencaoResponse> atualizar(@PathVariable("id") Long id,
                                                         @Valid @RequestBody IntervencaoUpdateRequest dados) {
        return ResponseEntity.ok(service.atualizar(id, dados));
    }

    /** DELETE /api/intervencoes/{id} -> 204 ou 404 */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> remover(@PathVariable("id") Long id) {
        service.remover(id);
        return ResponseEntity.noContent().build();
    }
}
