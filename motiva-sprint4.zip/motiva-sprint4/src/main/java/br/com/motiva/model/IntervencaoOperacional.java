package br.com.motiva.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.PrePersist;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

/**
 * Classe abstrata da Sprint 2, agora entidade JPA mapeada para
 * INTERVENCAO_OPERACIONAL.
 *
 * A coluna TIPO_INTERVENCAO da Sprint 3 ja guardava exatamente o nome da
 * subclasse ('RocadaManual', 'RocadaMecanizada', 'Pulverizacao'). Por isso
 * ela vira a coluna discriminadora da heranca SINGLE_TABLE: ao ler uma
 * linha, o Hibernate instancia sozinho a subclasse correta - o polimorfismo
 * da Sprint 2 continua funcionando com dados vindos do banco.
 *
 * As FKs TRECHO_ID e EQUIPE_ID viram relacionamentos @ManyToOne.
 */
@Entity
@Table(name = "INTERVENCAO_OPERACIONAL")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "TIPO_INTERVENCAO", discriminatorType = DiscriminatorType.STRING, length = 30)
public abstract class IntervencaoOperacional {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqIntervencaoOperacional")
    @SequenceGenerator(name = "seqIntervencaoOperacional", sequenceName = "SEQ_INTERVENCAO_OPERACIONAL",
            allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "TRECHO_ID", nullable = false)
    private TrechoRodovia trecho;

    @ManyToOne(optional = false)
    @JoinColumn(name = "EQUIPE_ID", nullable = false)
    private EquipeManutencao equipe;

    @Column(name = "DATA_EXECUCAO", nullable = false)
    private LocalDateTime dataExecucao;

    @Column(name = "RESULTADO", length = 300)
    private String resultado;

    /** Construtor exigido pela JPA. */
    protected IntervencaoOperacional() {
    }

    protected IntervencaoOperacional(EquipeManutencao equipe) {
        setEquipe(equipe);
    }

    /** Cada subclasse aplica seu efeito sobre o trecho (polimorfismo da Sprint 2). */
    public abstract String executarServico(TrechoRodovia trecho);

    /** Cada subclasse informa qual especialidade de equipe pode executa-la. */
    public abstract Especialidade getEspecialidadeExigida();

    /** Tipo da intervencao (mesmo valor gravado em TIPO_INTERVENCAO). */
    public abstract TipoIntervencao getTipo();

    /**
     * Template method: executa o servico polimorfico sobre o trecho e
     * registra os dados do historico (trecho, data e resultado).
     */
    public String executar(TrechoRodovia trechoAlvo) {
        if (trechoAlvo == null) {
            throw new IllegalArgumentException("Toda intervencao precisa de um trecho.");
        }
        this.trecho = trechoAlvo;
        this.resultado = executarServico(trechoAlvo);
        this.dataExecucao = LocalDateTime.now();
        return resultado;
    }

    @PrePersist
    void antesDeInserir() {
        if (dataExecucao == null) {
            dataExecucao = LocalDateTime.now();
        }
    }

    public Long getId() {
        return id;
    }

    public TrechoRodovia getTrecho() {
        return trecho;
    }

    public EquipeManutencao getEquipe() {
        return equipe;
    }

    public void setEquipe(EquipeManutencao equipe) {
        if (equipe == null) {
            throw new IllegalArgumentException("Toda intervencao precisa de uma equipe responsavel.");
        }
        this.equipe = equipe;
    }

    public LocalDateTime getDataExecucao() {
        return dataExecucao;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }
}
