package br.com.motiva.dto;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Corpo padrao de erro devolvido pelo GlobalExceptionHandler.
 * "campos" lista os erros de Bean Validation (quando houver).
 */
public record ErroResponse(
        LocalDateTime timestamp,
        int status,
        String erro,
        String mensagem,
        String caminho,
        List<CampoInvalido> campos
) {

    public record CampoInvalido(String campo, String mensagem) {
    }
}
