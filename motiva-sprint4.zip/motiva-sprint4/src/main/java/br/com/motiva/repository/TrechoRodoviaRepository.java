package br.com.motiva.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.motiva.model.TipoAmbiente;
import br.com.motiva.model.TrechoRodovia;

/**
 * Substitui o TrechoRodoviaDAO da Sprint 3 (~250 linhas de JDBC).
 * CRUD completo herdado de JpaRepository (save, findById, findAll, deleteById...).
 * Os metodos abaixo sao derived queries: o Spring Data le o NOME do metodo
 * e gera o JPQL/SQL em tempo de execucao. Nenhum SQL escrito a mao.
 */
@Repository
public interface TrechoRodoviaRepository extends JpaRepository<TrechoRodovia, Long> {

    /** SELECT ... ORDER BY KM_INICIAL */
    List<TrechoRodovia> findAllByOrderByKmInicialAsc();

    /** SELECT ... WHERE TIPO_AMBIENTE = ? ORDER BY KM_INICIAL */
    List<TrechoRodovia> findByTipoAmbienteOrderByKmInicialAsc(TipoAmbiente tipoAmbiente);

    /** SELECT ... WHERE ALTURA_VEGETACAO_CM >= ? ORDER BY ALTURA_VEGETACAO_CM DESC */
    List<TrechoRodovia> findByAlturaVegetacaoCmGreaterThanEqualOrderByAlturaVegetacaoCmDesc(Double minimo);

    /** SELECT ... WHERE TIPO_AMBIENTE = ? AND ALTURA_VEGETACAO_CM >= ? */
    List<TrechoRodovia> findByTipoAmbienteAndAlturaVegetacaoCmGreaterThanEqualOrderByAlturaVegetacaoCmDesc(
            TipoAmbiente tipoAmbiente, Double minimo);
}
