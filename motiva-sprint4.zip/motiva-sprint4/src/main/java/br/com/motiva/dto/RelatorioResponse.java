package br.com.motiva.dto;

import java.time.LocalDateTime;
import java.util.List;

import br.com.motiva.model.RelatorioPrioridade;

/**
 * Saida de um relatorio de prioridade.
 * - No historico (GET) "itens" vem vazio: a tabela RELATORIO_PRIORIDADE guarda so o resumo.
 * - Na geracao (POST) "itens" traz o detalhe de cada trecho analisado.
 */
public record RelatorioResponse(
        Long id,
        LocalDateTime dataGeracao,
        int totalTrechos,
        Integer qtBaixa,
        Integer qtMedia,
        Integer qtAlta,
        Integer qtCritica,
        String resumo,
        List<ItemRelatorioResponse> itens
) {

    public static RelatorioResponse de(RelatorioPrioridade relatorio) {
        return de(relatorio, List.of());
    }

    public static RelatorioResponse de(RelatorioPrioridade relatorio, List<ItemRelatorioResponse> itens) {
        return new RelatorioResponse(
                relatorio.getId(),
                relatorio.getDataGeracao(),
                relatorio.getTotalTrechos(),
                relatorio.getQtBaixa(),
                relatorio.getQtMedia(),
                relatorio.getQtAlta(),
                relatorio.getQtCritica(),
                relatorio.getResumo(),
                itens);
    }
}
