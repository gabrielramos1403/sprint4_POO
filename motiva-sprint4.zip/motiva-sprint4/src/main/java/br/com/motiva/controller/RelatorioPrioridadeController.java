package br.com.motiva.controller;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import br.com.motiva.dto.RelatorioResponse;
import br.com.motiva.service.MotorRegrasPrioridadeService;
import br.com.motiva.service.RelatorioPrioridadeService;

/**
 * O motor de prioridade das Sprints 2/3 exposto como servico REST.
 * A classificacao (CRITICA/ALTA/MEDIA/BAIXA) acontece no Service.
 */
@RestController
@RequestMapping("/api/relatorios")
public class RelatorioPrioridadeController {

    private final MotorRegrasPrioridadeService motorService;
    private final RelatorioPrioridadeService relatorioService;

    public RelatorioPrioridadeController(MotorRegrasPrioridadeService motorService,
                                         RelatorioPrioridadeService relatorioService) {
        this.motorService = motorService;
        this.relatorioService = relatorioService;
    }

    /** POST /api/relatorios -> 201: gera o relatorio a partir dos trechos atuais e grava no historico */
    @PostMapping
    public ResponseEntity<RelatorioResponse> gerar() {
        RelatorioResponse gerado = motorService.gerarRelatorio();
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}").buildAndExpand(gerado.id()).toUri();
        return ResponseEntity.created(location).body(gerado);
    }

    /** GET /api/relatorios -> 200: historico completo (mais recente primeiro) */
    @GetMapping
    public ResponseEntity<List<RelatorioResponse>> listarHistorico() {
        return ResponseEntity.ok(relatorioService.listarHistorico());
    }

    /** GET /api/relatorios/periodo?inicio=2026-10-01&fim=2026-10-31 -> 200 (ou 400) */
    @GetMapping("/periodo")
    public ResponseEntity<List<RelatorioResponse>> buscarPorPeriodo(
            @RequestParam(name = "inicio") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @RequestParam(name = "fim") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fim) {
        return ResponseEntity.ok(relatorioService.buscarPorPeriodo(inicio, fim));
    }

    /** GET /api/relatorios/{id} -> 200 ou 404 */
    @GetMapping("/{id}")
    public ResponseEntity<RelatorioResponse> buscarPorId(@PathVariable("id") Long id) {
        return ResponseEntity.ok(relatorioService.buscarPorId(id));
    }
}
