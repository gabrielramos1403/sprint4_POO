package br.com.motiva.model;

import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;

/**
 * Entidade JPA mapeada para a tabela EQUIPE_MANUTENCAO da Sprint 3.
 *
 * Antes: model.EquipeManutencao + record EquipeManutencaoRegistro dentro do
 * EquipeManutencaoDAO, com o SQL escrito a mao.
 * Agora: a propria classe de dominio e mapeada para a tabela via anotacoes,
 * e o Hibernate gera o SQL.
 */
@Entity
@Table(name = "EQUIPE_MANUTENCAO")
public class EquipeManutencao {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqEquipeManutencao")
    @SequenceGenerator(name = "seqEquipeManutencao", sequenceName = "SEQ_EQUIPE_MANUTENCAO", allocationSize = 1)
    @Column(name = "ID")
    private Long id;

    @Column(name = "NOME_EQUIPE", nullable = false, length = 100)
    private String nomeEquipe;

    @Enumerated(EnumType.STRING)
    @Column(name = "ESPECIALIDADE", nullable = false, length = 30)
    private Especialidade especialidade;

    @Convert(converter = SimNaoConverter.class)
    @Column(name = "ATIVA", nullable = false, length = 1)
    private Boolean ativa = Boolean.TRUE;

    /** Construtor exigido pela JPA (o Hibernate instancia a entidade por reflexao). */
    protected EquipeManutencao() {
    }

    public EquipeManutencao(String nomeEquipe, Especialidade especialidade, Boolean ativa) {
        this.nomeEquipe = nomeEquipe;
        this.especialidade = especialidade;
        this.ativa = ativa == null ? Boolean.TRUE : ativa;
    }

    /** Regra da Sprint 1/2: so uma equipe ativa e da especialidade certa pode executar o servico. */
    public boolean podeExecutar(Especialidade especialidadeExigida) {
        return Boolean.TRUE.equals(ativa) && especialidade == especialidadeExigida;
    }

    /** Substitui o antigo exibirAtendimento() que usava System.out.println. */
    public String descreverAtendimento(TrechoRodovia trecho) {
        return "Equipe " + nomeEquipe + " (" + especialidade + ") responsavel pelo trecho: "
                + trecho.obterIdentificacao();
    }

    public Long getId() {
        return id;
    }

    public String getNomeEquipe() {
        return nomeEquipe;
    }

    public void setNomeEquipe(String nomeEquipe) {
        this.nomeEquipe = nomeEquipe;
    }

    public Especialidade getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(Especialidade especialidade) {
        this.especialidade = especialidade;
    }

    public Boolean getAtiva() {
        return ativa;
    }

    public void setAtiva(Boolean ativa) {
        this.ativa = ativa;
    }

    @Override
    public String toString() {
        return "EquipeManutencao{id=" + id + ", nomeEquipe='" + nomeEquipe + "', especialidade="
                + especialidade + ", ativa=" + ativa + "}";
    }
}
