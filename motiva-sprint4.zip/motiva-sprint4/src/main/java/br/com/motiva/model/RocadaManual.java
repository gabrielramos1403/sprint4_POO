package br.com.motiva.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;

@Entity
@DiscriminatorValue("RocadaManual")
public class RocadaManual extends IntervencaoOperacional {

    protected RocadaManual() {
        super();
    }

    public RocadaManual(EquipeManutencao equipe) {
        super(equipe);
    }

    @Override
    public String executarServico(TrechoRodovia trecho) {
        trecho.setAlturaVegetacaoCm(10.0);
        return "Rocada manual executada pela " + getEquipe().getNomeEquipe()
                + ". Servico indicado por seguranca ou acesso dificil.";
    }

    @Override
    public Especialidade getEspecialidadeExigida() {
        return Especialidade.MANUAL;
    }

    @Override
    public TipoIntervencao getTipo() {
        return TipoIntervencao.ROCADA_MANUAL;
    }
}
