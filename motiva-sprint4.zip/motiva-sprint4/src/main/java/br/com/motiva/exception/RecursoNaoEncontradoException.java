package br.com.motiva.exception;

/** Lancada pelo Service quando o recurso pedido nao existe. Vira HTTP 404. */
public class RecursoNaoEncontradoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public RecursoNaoEncontradoException(String recurso, Long id) {
        super(recurso + " com id " + id + " nao encontrado(a).");
    }
}
