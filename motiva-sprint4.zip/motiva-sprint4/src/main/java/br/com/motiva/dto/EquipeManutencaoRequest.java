package br.com.motiva.dto;

import br.com.motiva.model.Especialidade;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

/**
 * Contrato de ENTRADA da API para criar/atualizar uma equipe.
 * "ativa" e opcional: se nao vier, a equipe e criada ativa (DEFAULT 'S' da tabela).
 */
public record EquipeManutencaoRequest(

        @NotBlank(message = "nomeEquipe e obrigatorio")
        @Size(max = 100, message = "nomeEquipe deve ter no maximo 100 caracteres")
        String nomeEquipe,

        @NotNull(message = "especialidade e obrigatoria (MECANIZADA, MANUAL ou PREVENTIVA)")
        Especialidade especialidade,

        Boolean ativa
) {
}
