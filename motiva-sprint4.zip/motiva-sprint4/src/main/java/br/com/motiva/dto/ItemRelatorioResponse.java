package br.com.motiva.dto;

import br.com.motiva.model.Prioridade;

/**
 * Linha do relatorio: o que o motor decidiu para cada trecho.
 * Equivale ao bloco que a Sprint 3 imprimia no console para cada trecho.
 */
public record ItemRelatorioResponse(
        Long trechoId,
        String trecho,
        String tipoAmbiente,
        Double leituraIoTCm,
        Double alturaAnteriorCm,
        Prioridade prioridade,
        String acaoRecomendada,
        Long intervencaoId,
        String resultado,
        Double alturaAtualCm
) {
}
