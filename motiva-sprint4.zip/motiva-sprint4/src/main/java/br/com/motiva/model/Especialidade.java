package br.com.motiva.model;

/**
 * Especialidades aceitas pela CHECK constraint CK_EQUIPE_ESPECIALIDADE.
 * Na Sprint 3 era uma String validada no setter de EquipeManutencao;
 * como enum o proprio compilador impede valores invalidos.
 */
public enum Especialidade {
    MECANIZADA,
    MANUAL,
    PREVENTIVA
}
