package br.com.motiva.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.motiva.model.IntervencaoOperacional;

/**
 * Substitui o IntervencaoOperacionalDAO da Sprint 3.
 * "trecho.id" e "equipe.id" sao navegados pelo nome do metodo (TrechoId, EquipeId).
 */
@Repository
public interface IntervencaoOperacionalRepository extends JpaRepository<IntervencaoOperacional, Long> {

    /** SELECT ... ORDER BY DATA_EXECUCAO DESC */
    List<IntervencaoOperacional> findAllByOrderByDataExecucaoDesc();

    /** SELECT ... WHERE TRECHO_ID = ? ORDER BY DATA_EXECUCAO DESC */
    List<IntervencaoOperacional> findByTrechoIdOrderByDataExecucaoDesc(Long trechoId);

    /** SELECT ... WHERE EQUIPE_ID = ? ORDER BY DATA_EXECUCAO DESC */
    List<IntervencaoOperacional> findByEquipeIdOrderByDataExecucaoDesc(Long equipeId);

    /** Usado para impedir apagar trecho que ja tem historico (evita ORA-02292). */
    boolean existsByTrechoId(Long trechoId);

    /** Usado para impedir apagar equipe que ja tem historico (evita ORA-02292). */
    boolean existsByEquipeId(Long equipeId);
}
