package br.com.motiva.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.motiva.dto.RelatorioResponse;
import br.com.motiva.exception.RecursoNaoEncontradoException;
import br.com.motiva.exception.RegraNegocioException;
import br.com.motiva.repository.RelatorioPrioridadeRepository;

/**
 * Consulta do historico de relatorios (RELATORIO_PRIORIDADE).
 * A GERACAO do relatorio fica no MotorRegrasPrioridadeService.
 */
@Service
public class RelatorioPrioridadeService {

    private final RelatorioPrioridadeRepository relatorioRepository;

    public RelatorioPrioridadeService(RelatorioPrioridadeRepository relatorioRepository) {
        this.relatorioRepository = relatorioRepository;
    }

    @Transactional(readOnly = true)
    public List<RelatorioResponse> listarHistorico() {
        return relatorioRepository.findAllByOrderByDataGeracaoDesc().stream()
                .map(RelatorioResponse::de)
                .toList();
    }

    @Transactional(readOnly = true)
    public RelatorioResponse buscarPorId(Long id) {
        return relatorioRepository.findById(id)
                .map(RelatorioResponse::de)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Relatorio", id));
    }

    /**
     * Historico por periodo, com as datas inclusivas:
     * inicio 00:00:00 ate fim 23:59:59.999999.
     */
    @Transactional(readOnly = true)
    public List<RelatorioResponse> buscarPorPeriodo(LocalDate inicio, LocalDate fim) {
        if (inicio.isAfter(fim)) {
            throw new RegraNegocioException("A data de inicio (" + inicio + ") nao pode ser posterior a data "
                    + "de fim (" + fim + ").");
        }
        return relatorioRepository
                .findByDataGeracaoBetweenOrderByDataGeracaoDesc(inicio.atStartOfDay(), fim.atTime(LocalTime.MAX))
                .stream()
                .map(RelatorioResponse::de)
                .toList();
    }
}
