package br.com.motiva.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * Contrato de ENTRADA para atualizar uma intervencao ja registrada.
 * O tipo e o trecho nao mudam (sao o proprio historico do que foi feito);
 * e possivel corrigir a equipe responsavel e o texto do resultado.
 */
public record IntervencaoUpdateRequest(

        @NotNull(message = "equipeId e obrigatorio")
        @Positive(message = "equipeId deve ser positivo")
        Long equipeId,

        @Size(max = 300, message = "resultado deve ter no maximo 300 caracteres")
        String resultado
) {
}
