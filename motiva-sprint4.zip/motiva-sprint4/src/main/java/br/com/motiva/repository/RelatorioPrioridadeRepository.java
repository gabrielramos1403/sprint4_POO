package br.com.motiva.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.motiva.model.RelatorioPrioridade;

/**
 * Substitui o RelatorioPrioridadeDAO da Sprint 3.
 */
@Repository
public interface RelatorioPrioridadeRepository extends JpaRepository<RelatorioPrioridade, Long> {

    /** SELECT ... ORDER BY DATA_GERACAO DESC */
    List<RelatorioPrioridade> findAllByOrderByDataGeracaoDesc();

    /** SELECT ... WHERE DATA_GERACAO BETWEEN ? AND ? ORDER BY DATA_GERACAO DESC */
    List<RelatorioPrioridade> findByDataGeracaoBetweenOrderByDataGeracaoDesc(LocalDateTime inicio,
                                                                            LocalDateTime fim);
}
