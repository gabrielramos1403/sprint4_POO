package br.com.motiva.dto;

import br.com.motiva.model.EquipeManutencao;
import br.com.motiva.model.Especialidade;

public record EquipeManutencaoResponse(
        Long id,
        String nomeEquipe,
        Especialidade especialidade,
        Boolean ativa
) {

    public static EquipeManutencaoResponse de(EquipeManutencao equipe) {
        return new EquipeManutencaoResponse(
                equipe.getId(),
                equipe.getNomeEquipe(),
                equipe.getEspecialidade(),
                equipe.getAtiva());
    }
}
