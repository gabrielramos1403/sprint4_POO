package br.com.motiva.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.motiva.model.EquipeManutencao;
import br.com.motiva.model.Especialidade;

/**
 * Substitui o EquipeManutencaoDAO da Sprint 3. Sem SQL: apenas derived queries.
 */
@Repository
public interface EquipeManutencaoRepository extends JpaRepository<EquipeManutencao, Long> {

    /** SELECT ... WHERE ESPECIALIDADE = ? ORDER BY ID */
    List<EquipeManutencao> findByEspecialidadeOrderByIdAsc(Especialidade especialidade);

    /** SELECT ... WHERE UPPER(NOME_EQUIPE) LIKE UPPER('%?%') */
    List<EquipeManutencao> findByNomeEquipeContainingIgnoreCaseOrderByIdAsc(String trecho);

    /**
     * Primeira equipe ativa de uma especialidade. Usada pelo motor de
     * prioridade para escolher quem executa cada intervencao.
     * SELECT ... WHERE ESPECIALIDADE = ? AND ATIVA = ? ORDER BY ID FETCH FIRST 1 ROW ONLY
     */
    Optional<EquipeManutencao> findFirstByEspecialidadeAndAtivaOrderByIdAsc(Especialidade especialidade,
                                                                             Boolean ativa);
}
