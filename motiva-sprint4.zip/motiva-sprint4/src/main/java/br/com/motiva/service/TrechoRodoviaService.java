package br.com.motiva.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.motiva.dto.TrechoRodoviaRequest;
import br.com.motiva.dto.TrechoRodoviaResponse;
import br.com.motiva.exception.ConflitoException;
import br.com.motiva.exception.RecursoNaoEncontradoException;
import br.com.motiva.exception.RegraNegocioException;
import br.com.motiva.model.TipoAmbiente;
import br.com.motiva.model.TrechoRodovia;
import br.com.motiva.model.TrechoRodoviaIoT;
import br.com.motiva.repository.IntervencaoOperacionalRepository;
import br.com.motiva.repository.TrechoRodoviaRepository;

/**
 * Regras de negocio dos trechos (validacoes da Sprint 1).
 * O Controller so recebe a requisicao HTTP e delega para ca; toda decisao
 * (o que e valido, o que pode ser apagado) fica nesta camada.
 */
@Service
public class TrechoRodoviaService {

    private final TrechoRodoviaRepository trechoRepository;
    private final IntervencaoOperacionalRepository intervencaoRepository;

    /** Injecao de dependencia via construtor (o Spring entrega os repositories prontos). */
    public TrechoRodoviaService(TrechoRodoviaRepository trechoRepository,
                                IntervencaoOperacionalRepository intervencaoRepository) {
        this.trechoRepository = trechoRepository;
        this.intervencaoRepository = intervencaoRepository;
    }

    /**
     * Lista os trechos, com filtros opcionais que usam as derived queries.
     */
    @Transactional(readOnly = true)
    public List<TrechoRodoviaResponse> listar(TipoAmbiente tipoAmbiente, Double alturaMinima) {
        if (alturaMinima != null && alturaMinima < 0) {
            throw new RegraNegocioException("alturaMinima nao pode ser negativa.");
        }

        List<TrechoRodovia> trechos;
        if (tipoAmbiente != null && alturaMinima != null) {
            trechos = trechoRepository
                    .findByTipoAmbienteAndAlturaVegetacaoCmGreaterThanEqualOrderByAlturaVegetacaoCmDesc(
                            tipoAmbiente, alturaMinima);
        } else if (tipoAmbiente != null) {
            trechos = trechoRepository.findByTipoAmbienteOrderByKmInicialAsc(tipoAmbiente);
        } else if (alturaMinima != null) {
            trechos = trechoRepository.findByAlturaVegetacaoCmGreaterThanEqualOrderByAlturaVegetacaoCmDesc(
                    alturaMinima);
        } else {
            trechos = trechoRepository.findAllByOrderByKmInicialAsc();
        }
        return trechos.stream().map(TrechoRodoviaResponse::de).toList();
    }

    @Transactional(readOnly = true)
    public TrechoRodoviaResponse buscarPorId(Long id) {
        return TrechoRodoviaResponse.de(buscarEntidade(id));
    }

    /**
     * Cria o trecho. Se vier codigoSensor, cria um TrechoRodoviaIoT
     * (polimorfismo); senao, um TrechoRodovia comum.
     */
    @Transactional
    public TrechoRodoviaResponse criar(TrechoRodoviaRequest dados) {
        validarRegras(dados);

        TrechoRodovia trecho;
        if (temSensor(dados.codigoSensor())) {
            trecho = new TrechoRodoviaIoT(dados.kmInicial(), dados.kmFinal(), dados.descricao(),
                    dados.tipoAmbiente(), dados.alturaVegetacaoCm(), dados.areaSinalizacao(),
                    dados.acessoDificil(), dados.codigoSensor().trim());
        } else {
            trecho = new TrechoRodovia(dados.kmInicial(), dados.kmFinal(), dados.descricao(),
                    dados.tipoAmbiente(), dados.alturaVegetacaoCm(), dados.areaSinalizacao(),
                    dados.acessoDificil());
        }
        return TrechoRodoviaResponse.de(trechoRepository.save(trecho));
    }

    @Transactional
    public TrechoRodoviaResponse atualizar(Long id, TrechoRodoviaRequest dados) {
        TrechoRodovia trecho = buscarEntidade(id);
        validarRegras(dados);

        boolean querSensor = temSensor(dados.codigoSensor());
        if (querSensor != trecho.possuiSensorIoT()) {
            throw new RegraNegocioException(trecho.possuiSensorIoT()
                    ? "Este trecho possui sensor IoT: informe o codigoSensor (o tipo do trecho nao pode mudar)."
                    : "Este trecho nao possui sensor IoT: o tipo do trecho nao pode mudar. "
                    + "Remova o codigoSensor ou cadastre um novo trecho com sensor.");
        }

        trecho.setKmInicial(dados.kmInicial());
        trecho.setKmFinal(dados.kmFinal());
        trecho.setDescricao(dados.descricao());
        trecho.setTipoAmbiente(dados.tipoAmbiente());
        trecho.setAlturaVegetacaoCm(dados.alturaVegetacaoCm());
        trecho.setAreaSinalizacao(dados.areaSinalizacao());
        trecho.setAcessoDificil(dados.acessoDificil());
        if (trecho instanceof TrechoRodoviaIoT trechoIoT) {
            trechoIoT.setCodigoSensor(dados.codigoSensor().trim());
        }

        // Entidade gerenciada: o Hibernate gera o UPDATE no commit (dirty checking).
        // O save() deixa a intencao explicita.
        return TrechoRodoviaResponse.de(trechoRepository.save(trecho));
    }

    @Transactional
    public void remover(Long id) {
        TrechoRodovia trecho = buscarEntidade(id);
        if (intervencaoRepository.existsByTrechoId(id)) {
            throw new ConflitoException("O trecho " + id + " possui intervencoes no historico e nao pode ser "
                    + "removido (FK_INTERVENCAO_TRECHO).");
        }
        trechoRepository.delete(trecho);
    }

    /** Simula o crescimento da vegetacao de todos os trechos (regra da Sprint 1). */
    @Transactional
    public List<TrechoRodoviaResponse> simularCrescimento(int dias) {
        if (dias <= 0 || dias > 365) {
            throw new RegraNegocioException("A quantidade de dias deve estar entre 1 e 365.");
        }
        List<TrechoRodovia> trechos = trechoRepository.findAllByOrderByKmInicialAsc();
        trechos.forEach(trecho -> trecho.simularCrescimento(dias));
        return trechoRepository.saveAll(trechos).stream().map(TrechoRodoviaResponse::de).toList();
    }

    /** Usado por outros services (intervencao, relatorio). */
    @Transactional(readOnly = true)
    public TrechoRodovia buscarEntidade(Long id) {
        return trechoRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Trecho", id));
    }

    /**
     * Validacoes de negocio da Sprint 1. Ficam no Service (e nao so no DTO)
     * porque valem para QUALQUER entrada do sistema, nao apenas para HTTP.
     */
    private void validarRegras(TrechoRodoviaRequest dados) {
        if (dados.kmInicial() == null || dados.kmInicial() < 0) {
            throw new RegraNegocioException("kmInicial deve ser maior ou igual a zero.");
        }
        if (dados.kmFinal() == null || dados.kmFinal() < dados.kmInicial()) {
            throw new RegraNegocioException("kmFinal deve ser maior ou igual ao kmInicial.");
        }
        if (dados.alturaVegetacaoCm() == null || dados.alturaVegetacaoCm() < 0) {
            throw new RegraNegocioException("A altura da vegetacao deve ser maior ou igual a zero.");
        }
        if (dados.tipoAmbiente() == null) {
            throw new RegraNegocioException("tipoAmbiente deve ser UMIDO ou SECO.");
        }
    }

    private boolean temSensor(String codigoSensor) {
        return codigoSensor != null && !codigoSensor.isBlank();
    }
}
