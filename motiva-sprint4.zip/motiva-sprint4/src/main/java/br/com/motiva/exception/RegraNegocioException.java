package br.com.motiva.exception;

/** Lancada pelo Service quando uma regra de negocio e violada. Vira HTTP 400. */
public class RegraNegocioException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public RegraNegocioException(String mensagem) {
        super(mensagem);
    }
}
