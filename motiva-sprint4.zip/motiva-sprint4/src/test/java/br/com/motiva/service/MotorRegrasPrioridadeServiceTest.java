package br.com.motiva.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import br.com.motiva.model.Prioridade;
import br.com.motiva.model.TipoAmbiente;
import br.com.motiva.model.TipoIntervencao;
import br.com.motiva.model.TrechoRodovia;

/**
 * Teste unitario das regras do motor (sem Spring e sem banco):
 * prova que a classificacao da Sprint 2 continua identica.
 */
class MotorRegrasPrioridadeServiceTest {

    // As regras puras nao usam os repositories, entao podem ser testadas isoladamente.
    private final MotorRegrasPrioridadeService motor = new MotorRegrasPrioridadeService(null, null, null, null);

    private TrechoRodovia trecho(double altura, TipoAmbiente ambiente, boolean sinalizacao, boolean acessoDificil) {
        return new TrechoRodovia(10, 11, "Trecho de teste", ambiente, altura, sinalizacao, acessoDificil);
    }

    @Test
    @DisplayName("Prioridade respeita os limiares 45 / 70 / 90 cm")
    void prioridadePorAltura() {
        assertEquals(Prioridade.BAIXA, motor.definirPrioridade(trecho(44.99, TipoAmbiente.SECO, false, false)));
        assertEquals(Prioridade.MEDIA, motor.definirPrioridade(trecho(45, TipoAmbiente.SECO, false, false)));
        assertEquals(Prioridade.ALTA, motor.definirPrioridade(trecho(70, TipoAmbiente.SECO, false, false)));
        assertEquals(Prioridade.CRITICA, motor.definirPrioridade(trecho(90, TipoAmbiente.SECO, false, false)));
    }

    @Test
    @DisplayName(">= 70 cm sem restricao -> rocada mecanizada")
    void rocadaMecanizada() {
        assertEquals(Optional.of(TipoIntervencao.ROCADA_MECANIZADA),
                motor.definirIntervencao(trecho(75, TipoAmbiente.SECO, false, false)));
    }

    @Test
    @DisplayName(">= 70 cm com sinalizacao ou acesso dificil -> rocada manual")
    void rocadaManual() {
        assertEquals(Optional.of(TipoIntervencao.ROCADA_MANUAL),
                motor.definirIntervencao(trecho(75, TipoAmbiente.UMIDO, true, false)));
        assertEquals(Optional.of(TipoIntervencao.ROCADA_MANUAL),
                motor.definirIntervencao(trecho(92, TipoAmbiente.SECO, false, true)));
    }

    @Test
    @DisplayName(">= 45 cm em ambiente umido -> pulverizacao; seco -> apenas monitorar")
    void pulverizacaoOuMonitorar() {
        assertEquals(Optional.of(TipoIntervencao.PULVERIZACAO),
                motor.definirIntervencao(trecho(55, TipoAmbiente.UMIDO, false, false)));
        assertTrue(motor.definirIntervencao(trecho(55, TipoAmbiente.SECO, false, false)).isEmpty());
        assertTrue(motor.definirIntervencao(trecho(20, TipoAmbiente.UMIDO, false, false)).isEmpty());
    }
}
