package br.com.motiva.controller;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.everyItem;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.empty;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.jayway.jsonpath.JsonPath;

/**
 * Testes de API (Aula 15): sobe o contexto Spring completo
 * (Controller -> Service -> Repository -> banco H2 em memoria)
 * e dispara requisicoes HTTP simuladas com MockMvc, conferindo
 * os codigos HTTP e o JSON devolvido.
 */
@SpringBootTest
@ActiveProfiles("test")
class MotivaApiIntegrationTest {

    @Autowired
    private WebApplicationContext context;

    private MockMvc mockMvc;

    @BeforeEach
    void configurarMockMvc() {
        mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    // ------------------------------------------------------------------
    // Utilitarios
    // ------------------------------------------------------------------

    private long criar(String url, String json) throws Exception {
        MvcResult resultado = mockMvc.perform(post(url).contentType(MediaType.APPLICATION_JSON).content(json))
                .andExpect(status().isCreated())
                .andReturn();
        Number id = JsonPath.read(resultado.getResponse().getContentAsString(), "$.id");
        return id.longValue();
    }

    private String trechoJson(int kmInicial, int kmFinal, String ambiente, double altura,
                              boolean sinalizacao, boolean acessoDificil, String codigoSensor) {
        String sensor = codigoSensor == null ? "null" : "\"" + codigoSensor + "\"";
        return """
                {"kmInicial": %d, "kmFinal": %d, "descricao": "Trecho de teste", "tipoAmbiente": "%s",
                 "alturaVegetacaoCm": %s, "areaSinalizacao": %s, "acessoDificil": %s, "codigoSensor": %s}
                """.formatted(kmInicial, kmFinal, ambiente, Double.toString(altura), sinalizacao, acessoDificil,
                sensor);
    }

    private long criarEquipe(String nome, String especialidade) throws Exception {
        return criar("/api/equipes", """
                {"nomeEquipe": "%s", "especialidade": "%s", "ativa": true}
                """.formatted(nome, especialidade));
    }

    // ------------------------------------------------------------------
    // Trechos
    // ------------------------------------------------------------------

    @Test
    @DisplayName("CRUD de trecho: 201 -> 200 -> 200 -> 204 -> 404")
    void crudCompletoDeTrecho() throws Exception {
        MvcResult criado = mockMvc.perform(post("/api/trechos").contentType(MediaType.APPLICATION_JSON)
                        .content(trechoJson(100, 101, "SECO", 38, false, false, null)))
                .andExpect(status().isCreated())
                .andExpect(header().string("Location", containsString("/api/trechos/")))
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.tipoAmbiente").value("SECO"))
                .andExpect(jsonPath("$.possuiSensorIoT").value(false))
                .andReturn();
        long id = ((Number) JsonPath.read(criado.getResponse().getContentAsString(), "$.id")).longValue();

        mockMvc.perform(get("/api/trechos/{id}", id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.alturaVegetacaoCm").value(38.0));

        mockMvc.perform(put("/api/trechos/{id}", id).contentType(MediaType.APPLICATION_JSON)
                        .content(trechoJson(100, 102, "UMIDO", 60, true, false, null)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.kmFinal").value(102))
                .andExpect(jsonPath("$.tipoAmbiente").value("UMIDO"))
                .andExpect(jsonPath("$.areaSinalizacao").value(true));

        mockMvc.perform(delete("/api/trechos/{id}", id))
                .andExpect(status().isNoContent());

        mockMvc.perform(get("/api/trechos/{id}", id))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404));
    }

    @Test
    @DisplayName("Validacoes de trecho devolvem 400")
    void validacoesDeTrecho() throws Exception {
        // Bean Validation: altura negativa
        mockMvc.perform(post("/api/trechos").contentType(MediaType.APPLICATION_JSON)
                        .content(trechoJson(1, 2, "SECO", -5, false, false, null)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.campos[0].campo").value("alturaVegetacaoCm"));

        // Regra de negocio do Service: kmFinal menor que kmInicial
        mockMvc.perform(post("/api/trechos").contentType(MediaType.APPLICATION_JSON)
                        .content(trechoJson(50, 10, "SECO", 30, false, false, null)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.mensagem", containsString("kmFinal")));

        // Enum invalido no JSON
        mockMvc.perform(post("/api/trechos").contentType(MediaType.APPLICATION_JSON)
                        .content(trechoJson(1, 2, "MOLHADO", 30, false, false, null)))
                .andExpect(status().isBadRequest());

        // ID com tipo errado na URL
        mockMvc.perform(get("/api/trechos/abc"))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Trecho com sensor vira TrechoRodoviaIoT (heranca JPA) e o tipo nao pode mudar")
    void trechoComSensorIoT() throws Exception {
        long id = criar("/api/trechos", trechoJson(200, 201, "UMIDO", 68, false, false, "IOT-200"));

        mockMvc.perform(get("/api/trechos/{id}", id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.possuiSensorIoT").value(true))
                .andExpect(jsonPath("$.codigoSensor").value("IOT-200"));

        mockMvc.perform(put("/api/trechos/{id}", id).contentType(MediaType.APPLICATION_JSON)
                        .content(trechoJson(200, 201, "UMIDO", 68, false, false, null)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Filtros usam as derived queries")
    void filtrosDeTrecho() throws Exception {
        criar("/api/trechos", trechoJson(300, 301, "UMIDO", 80, false, false, null));
        criar("/api/trechos", trechoJson(302, 303, "SECO", 20, false, false, null));

        mockMvc.perform(get("/api/trechos").param("tipoAmbiente", "UMIDO"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", not(empty())))
                .andExpect(jsonPath("$[*].tipoAmbiente", everyItem(is("UMIDO"))));

        mockMvc.perform(get("/api/trechos").param("alturaMinima", "75"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", not(empty())))
                .andExpect(jsonPath("$[*].alturaVegetacaoCm", everyItem(greaterThanOrEqualTo(75.0))));
    }

    // ------------------------------------------------------------------
    // Equipes
    // ------------------------------------------------------------------

    @Test
    @DisplayName("CRUD de equipe: 201 -> 200 -> 200 -> 204 -> 404")
    void crudCompletoDeEquipe() throws Exception {
        long id = criarEquipe("Equipe Teste CRUD", "MANUAL");

        mockMvc.perform(get("/api/equipes/{id}", id))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.especialidade").value("MANUAL"))
                .andExpect(jsonPath("$.ativa").value(true));

        mockMvc.perform(put("/api/equipes/{id}", id).contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"nomeEquipe": "Equipe Teste Atualizada", "especialidade": "PREVENTIVA", "ativa": false}
                                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nomeEquipe").value("Equipe Teste Atualizada"))
                .andExpect(jsonPath("$.ativa").value(false));

        mockMvc.perform(delete("/api/equipes/{id}", id)).andExpect(status().isNoContent());
        mockMvc.perform(get("/api/equipes/{id}", id)).andExpect(status().isNotFound());
        mockMvc.perform(delete("/api/equipes/{id}", id)).andExpect(status().isNotFound());
    }

    @Test
    @DisplayName("Equipe sem nome devolve 400")
    void equipeInvalida() throws Exception {
        mockMvc.perform(post("/api/equipes").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"nomeEquipe\": \"\", \"especialidade\": \"MANUAL\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.campos[0].campo").value("nomeEquipe"));
    }

    // ------------------------------------------------------------------
    // Intervencoes
    // ------------------------------------------------------------------

    @Test
    @DisplayName("Intervencao: especialidade errada 400, execucao 201, conflito 409, update 200, delete 204")
    void cicloDeIntervencao() throws Exception {
        long trechoId = criar("/api/trechos", trechoJson(400, 401, "SECO", 85, false, false, null));
        long equipeManual = criarEquipe("Equipe Manual Teste", "MANUAL");
        long equipeMecanizada = criarEquipe("Equipe Mecanizada Teste", "MECANIZADA");
        long outraMecanizada = criarEquipe("Equipe Mecanizada Reserva", "MECANIZADA");

        // Regra de negocio: rocada mecanizada exige equipe MECANIZADA
        mockMvc.perform(post("/api/intervencoes").contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"tipo": "ROCADA_MECANIZADA", "trechoId": %d, "equipeId": %d}
                                """.formatted(trechoId, equipeManual)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.mensagem", containsString("MECANIZADA")));

        // Execucao correta: altura do trecho cai para 8 cm (polimorfismo de RocadaMecanizada)
        MvcResult criada = mockMvc.perform(post("/api/intervencoes").contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"tipo": "ROCADA_MECANIZADA", "trechoId": %d, "equipeId": %d}
                                """.formatted(trechoId, equipeMecanizada)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.classe").value("RocadaMecanizada"))
                .andExpect(jsonPath("$.alturaAtualTrechoCm").value(8.0))
                .andReturn();
        long intervencaoId = ((Number) JsonPath.read(criada.getResponse().getContentAsString(), "$.id"))
                .longValue();

        mockMvc.perform(get("/api/trechos/{id}", trechoId))
                .andExpect(jsonPath("$.alturaVegetacaoCm").value(8.0));

        mockMvc.perform(get("/api/intervencoes").param("trechoId", String.valueOf(trechoId)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value((int) intervencaoId));

        // Trecho com historico nao pode ser apagado
        mockMvc.perform(delete("/api/trechos/{id}", trechoId))
                .andExpect(status().isConflict());

        mockMvc.perform(put("/api/intervencoes/{id}", intervencaoId).contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"equipeId": %d, "resultado": "Servico conferido pela fiscalizacao."}
                                """.formatted(outraMecanizada)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.equipeId").value((int) outraMecanizada))
                .andExpect(jsonPath("$.resultado").value("Servico conferido pela fiscalizacao."));

        mockMvc.perform(delete("/api/intervencoes/{id}", intervencaoId)).andExpect(status().isNoContent());
        mockMvc.perform(get("/api/intervencoes/{id}", intervencaoId)).andExpect(status().isNotFound());
    }

    // ------------------------------------------------------------------
    // Relatorios
    // ------------------------------------------------------------------

    @Test
    @DisplayName("Relatorio: gerar 201, historico 200, periodo 200 e periodo invalido 400")
    void relatorioDePrioridade() throws Exception {
        criarEquipe("Equipe Mecanizada Relatorio", "MECANIZADA");
        criarEquipe("Equipe Manual Relatorio", "MANUAL");
        criarEquipe("Equipe Preventiva Relatorio", "PREVENTIVA");
        long critico = criar("/api/trechos", trechoJson(500, 501, "SECO", 95, false, true, null));

        mockMvc.perform(post("/api/relatorios"))
                .andExpect(status().isCreated())
                .andExpect(header().string("Location", containsString("/api/relatorios/")))
                .andExpect(jsonPath("$.id").isNumber())
                .andExpect(jsonPath("$.qtCritica", greaterThanOrEqualTo(1)))
                .andExpect(jsonPath("$.itens", not(empty())))
                .andExpect(jsonPath("$.itens[?(@.trechoId == " + critico + ")].acaoRecomendada")
                        .value("RocadaManual"));

        mockMvc.perform(get("/api/relatorios"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", not(empty())));

        String hoje = LocalDate.now().toString();
        mockMvc.perform(get("/api/relatorios/periodo").param("inicio", hoje).param("fim", hoje))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", not(empty())));

        mockMvc.perform(get("/api/relatorios/periodo").param("inicio", "2026-12-31").param("fim", "2026-01-01"))
                .andExpect(status().isBadRequest());

        mockMvc.perform(get("/api/relatorios/periodo").param("inicio", "2026-01-01"))
                .andExpect(status().isBadRequest());

        mockMvc.perform(get("/api/relatorios/periodo").param("inicio", "31/12/2026").param("fim", "2026-12-31"))
                .andExpect(status().isBadRequest());

        mockMvc.perform(get("/api/relatorios/{id}", 999999)).andExpect(status().isNotFound());
    }
}
