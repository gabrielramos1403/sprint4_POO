--------------------------------------------------------------------
-- MOTIVA - Sprint 4
-- MIGRACAO das tabelas da Sprint 3 para SEQUENCES
--
-- Por que este script existe?
--   Na Sprint 3 as chaves primarias foram criadas com
--   "GENERATED ALWAYS AS IDENTITY". Na Sprint 4 as entidades JPA usam
--   @GeneratedValue(strategy = SEQUENCE) + @SequenceGenerator, ou seja,
--   o Hibernate busca o proximo ID em uma SEQUENCE e envia o valor no
--   INSERT. Uma coluna "GENERATED ALWAYS" recusaria esse valor (ORA-32795).
--
-- O que ele faz (sem apagar nenhum dado):
--   1. remove a propriedade IDENTITY da coluna ID das 4 tabelas;
--   2. cria uma sequence para cada tabela, comecando no MAIOR ID + 1,
--      para nao colidir com as linhas que ja existem.
--
-- Pode ser executado mais de uma vez sem erro (e idempotente).
-- Rode UMA vez no SQL Developer (F5 - "Executar script") antes de subir a API.
--------------------------------------------------------------------
SET SERVEROUTPUT ON;

DECLARE
    PROCEDURE migrar(p_tabela IN VARCHAR2, p_sequence IN VARCHAR2) IS
        v_identity NUMBER;
        v_existe   NUMBER;
        v_inicio   NUMBER;
    BEGIN
        -- 1. Remove o IDENTITY (se ainda existir)
        SELECT COUNT(*) INTO v_identity
          FROM USER_TAB_IDENTITY_COLS
         WHERE TABLE_NAME = p_tabela AND COLUMN_NAME = 'ID';

        IF v_identity > 0 THEN
            EXECUTE IMMEDIATE 'ALTER TABLE ' || p_tabela || ' MODIFY ID DROP IDENTITY';
            DBMS_OUTPUT.PUT_LINE('IDENTITY removido de ' || p_tabela || '.ID');
        END IF;

        -- 2. Cria a sequence a partir do maior ID existente
        SELECT COUNT(*) INTO v_existe FROM USER_SEQUENCES WHERE SEQUENCE_NAME = p_sequence;

        IF v_existe = 0 THEN
            EXECUTE IMMEDIATE 'SELECT NVL(MAX(ID), 0) + 1 FROM ' || p_tabela INTO v_inicio;
            EXECUTE IMMEDIATE 'CREATE SEQUENCE ' || p_sequence
                           || ' START WITH ' || v_inicio || ' INCREMENT BY 1 NOCACHE';
            DBMS_OUTPUT.PUT_LINE('Sequence ' || p_sequence || ' criada comecando em ' || v_inicio);
        ELSE
            DBMS_OUTPUT.PUT_LINE('Sequence ' || p_sequence || ' ja existia - mantida.');
        END IF;
    END migrar;
BEGIN
    migrar('EQUIPE_MANUTENCAO',       'SEQ_EQUIPE_MANUTENCAO');
    migrar('TRECHO_RODOVIA',          'SEQ_TRECHO_RODOVIA');
    migrar('INTERVENCAO_OPERACIONAL', 'SEQ_INTERVENCAO_OPERACIONAL');
    migrar('RELATORIO_PRIORIDADE',    'SEQ_RELATORIO_PRIORIDADE');
END;
/

-- Conferencia
SELECT SEQUENCE_NAME, LAST_NUMBER FROM USER_SEQUENCES WHERE SEQUENCE_NAME LIKE 'SEQ_%' ORDER BY 1;
