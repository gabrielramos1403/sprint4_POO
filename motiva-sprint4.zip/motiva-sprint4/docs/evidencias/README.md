# Registro das requisicoes - API MOTIVA (Sprint 4)

Requisicoes executadas em **23/10/2026, as 23:16**, com a API rodando no Eclipse (`MotivaApplication`, porta 8085) e conectada ao **Oracle da FIAP** (`oracle.fiap.com.br`, Oracle 19.3). Cada linha abaixo tem um print correspondente nesta pasta.

| # | Metodo | Rota | Status | O que mostra | Print |
| --- | --- | --- | --- | --- | --- |
| 1 | GET | `/api/equipes` | **200** | Listar equipes | [01-get-listar-equipes.png](01-get-listar-equipes.png) |
| 2 | POST | `/api/equipes` | **201** | Criar equipe | [02-post-criar-equipe.png](02-post-criar-equipe.png) |
| 3 | GET | `/api/equipes/4` | **200** | Buscar equipe por ID | [03-get-buscar-equipe-por-id.png](03-get-buscar-equipe-por-id.png) |
| 4 | PUT | `/api/equipes/4` | **200** | Atualizar equipe | [04-put-atualizar-equipe.png](04-put-atualizar-equipe.png) |
| 5 | GET | `/api/equipes?especialidade=MECANIZADA` | **200** | Filtrar equipes por especialidade (derived query) | [05-get-filtrar-equipes-por-especialidade-derived-query.png](05-get-filtrar-equipes-por-especialidade-derived-query.png) |
| 6 | POST | `/api/equipes` | **400** | Validacao: equipe sem nome | [06-post-validacao-equipe-sem-nome.png](06-post-validacao-equipe-sem-nome.png) |
| 7 | POST | `/api/trechos` | **201** | Criar trecho | [07-post-criar-trecho.png](07-post-criar-trecho.png) |
| 8 | GET | `/api/trechos/6` | **200** | Buscar trecho por ID | [08-get-buscar-trecho-por-id.png](08-get-buscar-trecho-por-id.png) |
| 9 | PUT | `/api/trechos/6` | **200** | Atualizar trecho | [09-put-atualizar-trecho.png](09-put-atualizar-trecho.png) |
| 10 | GET | `/api/trechos?tipoAmbiente=UMIDO&alturaMinima=50` | **200** | Filtrar trechos (derived query) | [10-get-filtrar-trechos-derived-query.png](10-get-filtrar-trechos-derived-query.png) |
| 11 | GET | `/api/trechos/99999` | **404** | Trecho inexistente | [11-get-trecho-inexistente.png](11-get-trecho-inexistente.png) |
| 12 | POST | `/api/trechos` | **400** | Validacao: altura negativa | [12-post-validacao-altura-negativa.png](12-post-validacao-altura-negativa.png) |
| 13 | POST | `/api/trechos` | **400** | Regra de negocio: kmFinal < kmInicial | [13-post-regra-de-negocio-kmfinal-kminicial.png](13-post-regra-de-negocio-kmfinal-kminicial.png) |
| 14 | POST | `/api/intervencoes` | **400** | Regra de negocio: equipe com especialidade errada | [14-post-regra-de-negocio-equipe-com-especialidade-errada.png](14-post-regra-de-negocio-equipe-com-especialidade-errada.png) |
| 15 | POST | `/api/intervencoes` | **201** | Executar intervencao (rocada mecanizada) | [15-post-executar-intervencao-rocada-mecanizada.png](15-post-executar-intervencao-rocada-mecanizada.png) |
| 16 | GET | `/api/intervencoes?trechoId=6` | **200** | Historico de intervencoes do trecho | [16-get-historico-de-intervencoes-do-trecho.png](16-get-historico-de-intervencoes-do-trecho.png) |
| 17 | DELETE | `/api/trechos/6` | **409** | Remover trecho com historico (conflito) | [17-delete-remover-trecho-com-historico-conflito.png](17-delete-remover-trecho-com-historico-conflito.png) |
| 18 | PUT | `/api/intervencoes/1` | **200** | Atualizar intervencao | [18-put-atualizar-intervencao.png](18-put-atualizar-intervencao.png) |
| 19 | DELETE | `/api/intervencoes/1` | **204** | Remover intervencao | [19-delete-remover-intervencao.png](19-delete-remover-intervencao.png) |
| 20 | DELETE | `/api/trechos/6` | **204** | Remover trecho | [20-delete-remover-trecho.png](20-delete-remover-trecho.png) |
| 21 | GET | `/api/trechos/6` | **404** | Buscar trecho removido | [21-get-buscar-trecho-removido.png](21-get-buscar-trecho-removido.png) |
| 22 | POST | `/api/trechos/simulacao-crescimento?dias=7` | **200** | Simular crescimento (7 dias) | [22-post-simular-crescimento-7-dias.png](22-post-simular-crescimento-7-dias.png) |
| 23 | POST | `/api/relatorios` | **201** | Gerar relatorio de prioridade | [23-post-gerar-relatorio-de-prioridade.png](23-post-gerar-relatorio-de-prioridade.png) |
| 24 | GET | `/api/relatorios` | **200** | Historico de relatorios | [24-get-historico-de-relatorios.png](24-get-historico-de-relatorios.png) |
| 25 | GET | `/api/relatorios/periodo?inicio=2026-10-23&fim=2026-10-23` | **200** | Relatorios por periodo | [25-get-relatorios-por-periodo.png](25-get-relatorios-por-periodo.png) |
| 26 | GET | `/api/relatorios/periodo?inicio=2026-12-31&fim=2026-01-01` | **400** | Periodo invertido | [26-get-periodo-invertido.png](26-get-periodo-invertido.png) |
| 27 | GET | `/api/relatorios/1` | **200** | Buscar relatorio por ID | [27-get-buscar-relatorio-por-id.png](27-get-buscar-relatorio-por-id.png) |

O arquivo [`requisicoes-oracle.json`](requisicoes-oracle.json) guarda o corpo completo de cada requisicao e de cada resposta.
